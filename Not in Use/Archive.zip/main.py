"""
MFD Portfolio Intelligence — Streamlit App
Updated: Folio Normalization + Full Precision Brokerage + Month Filters + RTA Bifurcation + AMC Breakdown
+ CAMS AUM Report Upload + Total AUM on Dashboard + Client Invested Amount
+ KFINTECH AUM Report Upload + KFinTech AUM Dashboard Integration
+ KFINTECH BROKERAGE UPLOAD + RECONCILIATION + CLIENT VIEW INTEGRATION
+ Admin Panel Revamp: Import BSE Data tab, merged RTA Data Upload tab
+ Smart Upsert: skip existing records, Replace = delete+reinsert only that dataset
+ Removed RTA filters from all pages, moved refresh/notifications to Dashboard only
+ Fixed dark mode CSS theming
"""

import logging
import re
import sqlite3
import threading
import warnings
from contextlib import contextmanager
from datetime import datetime, timedelta

import pandas as pd
import plotly.express as px
import requests
import streamlit as st
from streamlit.runtime.scriptrunner import add_script_run_ctx

import data_maneger

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.WARNING, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ==================== CONSTANTS ====================
DB_PATH = "mfd_local.db"
AMFI_TEXT_URL = "https://portal.amfiindia.com/spages/NAVAll.txt"
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
CANCELLED_KEYWORDS = frozenset(
    ["CXL", "AUTOCXL", "AUTO CXL", "CX", "CANCEL", "CLOSED", "REDEEM", "STOPPED", "FAILED"]
)
AMC_SUFFIXES = [
    " MUTUAL FUND", " MF", " FUND", " AMC",
    " INDIA", " MANAGEMENT", " LTD", " LIMITED",
]
_WHITESPACE_RE = re.compile(r"\s+")
PAGE_SIZE = 20

# Normalized RTA Lists (auto-matched against AMC names)
CAMS_AMCS = frozenset([
    "360 ONE", "ADITYA BIRLA SUN LIFE", "ANGEL ONE", "BANDHAN", "DSP",
    "FRANKLIN TEMPLETON", "HDFC", "HELIOS", "HSBC", "ICICI PRUDENTIAL",
    "JIO BLACKROCK", "KOTAK", "MAHINDRA MANULIFE", "NAVI", "PARAG PARIKH", "PPFAS",
    "SBI", "SHRIRAM", "TATA", "UNIFI", "UNION", "WHITEOAK", "ZERODHA"
])
KFIN_AMCS = frozenset([
    "AXIS", "BARODA BNP PARIBAS", "BANK OF INDIA", "BAJAJ FINSERV",
    "CANARA ROBECO", "CAPITALMIND", "EDELWEISS", "GROWW", "INVESTECO",
    "ITI", "JM FINANCIAL", "LIC", "MIRAE ASSET", "MOTILAL OSWAL",
    "NIPPON INDIA", "OLD BRIDGE", "NJ", "PGIM", "QUANTUM", "QUANT",
    "SAMCO", "SUNDARAM", "TRUST", "TAURUS", "UTI"
])


# ==================== DB HELPERS ====================
@contextmanager
def get_conn():
    # Add a timeout to handle concurrent write locks gracefully
    conn = sqlite3.connect(DB_PATH, timeout=20, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    if not st.session_state.get("db_initialized"):
        with get_conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS clients (
                    client_code TEXT PRIMARY KEY,
                    name        TEXT,
                    pan         TEXT,
                    mobile      TEXT,
                    email       TEXT,
                    kyc_status  TEXT,
                    start_date  TEXT,
                    notes       TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS holdings (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    client_code     TEXT,
                    folio_no        TEXT,
                    scheme_code     TEXT,
                    scheme_name     TEXT,
                    amc             TEXT,
                    rta             TEXT DEFAULT 'Unknown',
                    investment_type TEXT,
                    sip_amount      REAL,
                    sip_day         INTEGER DEFAULT 1,
                    start_date      TEXT,
                    end_date        TEXT,
                    status          TEXT DEFAULT 'Active',
                    first_order     TEXT DEFAULT 'N'
                );
                CREATE TABLE IF NOT EXISTS amc_schemes (
                    scheme_code TEXT PRIMARY KEY,
                    amc         TEXT,
                    rta         TEXT DEFAULT 'Unknown',
                    scheme_name TEXT,
                    category    TEXT,
                    last_nav    REAL,
                    nav_date    TEXT
                );
                CREATE TABLE IF NOT EXISTS amc_config (
                    amc        TEXT PRIMARY KEY,
                    rta        TEXT DEFAULT 'Unknown',
                    is_enabled INTEGER DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS monthly_brokerage (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    amc       TEXT,
                    month     TEXT,
                    year      INTEGER,
                    amount    REAL,
                    notes     TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                );
            
                CREATE TABLE IF NOT EXISTS kfintech_aum (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    folio_no        TEXT,
                    inv_name        TEXT,
                    scheme_name     TEXT,
                    amc_code        TEXT,
                    product_code    TEXT,
                    scheme_code     TEXT,
                    dividend_opt    TEXT,
                    email           TEXT,
                    rep_date        TEXT,
                    units           REAL,
                    rupee_bal       REAL,
                    nav             REAL,
                    aum             REAL,
                    upload_batch    TEXT,
                    UNIQUE(folio_no, scheme_name, rep_date)
                );
                CREATE TABLE IF NOT EXISTS cams_transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        amc_code        TEXT,
        folio_no        TEXT,
        scheme_code     TEXT,
        scheme_name     TEXT,
        inv_name        TEXT,
        trxn_type       TEXT,
        trxn_no         TEXT,
        trxn_mode       TEXT,
        trxn_status     TEXT,
        trade_date      TEXT,
        post_date       TEXT,
        nav             REAL,
        units           REAL,
        amount          REAL,
        pan             TEXT,
        remarks         TEXT,
        sip_trxn_no     TEXT,
        igst_amount     REAL DEFAULT 0,
        cgst_amount     REAL DEFAULT 0,
        sgst_amount     REAL DEFAULT 0,
        rep_date        TEXT,
        upload_batch    TEXT,
        UNIQUE(trxn_no, folio_no)
    );
    CREATE TABLE IF NOT EXISTS cams_folio_master (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        folio_no         TEXT,
        inv_name         TEXT,
        address1         TEXT,
        address2         TEXT,
        address3         TEXT,
        city             TEXT,
        pincode          TEXT,
        scheme_code      TEXT,
        scheme_name      TEXT,
        amc_code         TEXT,
        rep_date         TEXT,
        units            REAL,
        rupee_bal        REAL,
        email            TEXT,
        mobile           TEXT,
        pan_no           TEXT,
        joint1_pan       TEXT,
        joint2_pan       TEXT,
        tax_status       TEXT,
        holding_nature   TEXT,
        bank_name        TEXT,
        branch           TEXT,
        ac_type          TEXT,
        ac_no            TEXT,
        ifsc_code        TEXT,
        inv_dob          TEXT,
        nominee_name     TEXT,
        nominee_relation TEXT,
        folio_date       TEXT,
        upload_batch     TEXT,
        UNIQUE(folio_no, scheme_name)
    );
    CREATE TABLE IF NOT EXISTS cams_sip_master (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        amc_code        TEXT,
        scheme_code     TEXT,
        scheme_name     TEXT,
        folio_no        TEXT,
        inv_name        TEXT,
        sip_reg_no      TEXT,
        sip_amount      REAL,
        from_date       TEXT,
        to_date         TEXT,
        cease_date      TEXT,
        periodicity     TEXT,
        sip_day         INTEGER,
        pan             TEXT,
        payment_mode    TEXT,
        bank_name       TEXT,
        reg_date        TEXT,
        remarks         TEXT,
        status          TEXT,
        upload_batch    TEXT,
        UNIQUE(sip_reg_no, folio_no)
    );

    CREATE TABLE IF NOT EXISTS kfintech_transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    product_code    TEXT,
    fund_code       TEXT,
    folio_no        TEXT,
    scheme_code     TEXT,
    div_opt         TEXT,
    scheme_name     TEXT,
    pur_red         TEXT,
    trxn_no         TEXT,
    inv_name        TEXT,
    trxn_mode       TEXT,
    trxn_status     TEXT,
    branch          TEXT,
    trade_date      TEXT,
    post_date       TEXT,
    nav             REAL,
    units           REAL,
    amount          REAL,
    load_amount     REAL,
    agent_code      TEXT,
    broker_code     TEXT,
    broker_pct      REAL,
    broker_comm     REAL,
    stt             REAL DEFAULT 0,
    pan             TEXT,
    sip_reg_no      TEXT,
    sip_reg_date    TEXT,
    chq_bank        TEXT,
    chq_date        TEXT,
    trxn_type       TEXT,
    trdesc          TEXT,
    pur_date        TEXT,
    pur_amt         REAL,
    pur_units       REAL,
    trflag          TEXT,
    sfund_date      TEXT,
    ih_no           TEXT,
    branch_code     TEXT,
    inward_no       TEXT,
    remarks         TEXT,
    guard_pan       TEXT,
    can             TEXT,
    exch_org_trtype TEXT,
    elec_trxn_flag  TEXT,
    cleared         TEXT,
    inv_state       TEXT,
    rep_date        TEXT,
    upload_batch    TEXT,
    UNIQUE(trxn_no, folio_no)
);
CREATE TABLE IF NOT EXISTS kfintech_folio_master (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    product_code     TEXT,
    fund_code        TEXT,
    folio_no         TEXT,
    div_opt          TEXT,
    scheme_name      TEXT,
    inv_name         TEXT,
    joint1_name      TEXT,
    joint2_name      TEXT,
    address1         TEXT,
    address2         TEXT,
    address3         TEXT,
    city             TEXT,
    pincode          TEXT,
    state            TEXT,
    country          TEXT,
    dob              TEXT,
    email            TEXT,
    mobile           TEXT,
    pan_no           TEXT,
    tax_status       TEXT,
    occ_code         TEXT,
    occ_desc         TEXT,
    holding_nature   TEXT,
    mapin_id         TEXT,
    bank_name        TEXT,
    branch           TEXT,
    ac_type          TEXT,
    ac_no            TEXT,
    bank_address1    TEXT,
    bank_address2    TEXT,
    bank_address3    TEXT,
    bank_city        TEXT,
    bank_state       TEXT,
    broker_code      TEXT,
    aadhaar1         TEXT,
    aadhaar2         TEXT,
    aadhaar3         TEXT,
    guardian_aadhaar TEXT,
    rep_date         TEXT,
    upload_batch     TEXT,
    UNIQUE(folio_no, scheme_name)
);
CREATE TABLE IF NOT EXISTS kfintech_sip_master (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    zone            TEXT,
    branch          TEXT,
    location        TEXT,
    ih_no           TEXT,
    folio_no        TEXT,
    inv_name        TEXT,
    reg_date        TEXT,
    from_date       TEXT,
    to_date         TEXT,
    installments    INTEGER,
    sip_amount      REAL,
    scheme          TEXT,
    plan            TEXT,
    agent_code      TEXT,
    agent_name      TEXT,
    subbroker       TEXT,
    scheme_name     TEXT,
    pan             TEXT,
    sip_type        TEXT,
    sip_mode        TEXT,
    fund_code       TEXT,
    product_code    TEXT,
    frequency       TEXT,
    trtype          TEXT,
    to_scheme       TEXT,
    to_plan         TEXT,
    terminate_date  TEXT,
    status          TEXT,
    to_product_code TEXT,
    to_scheme_name  TEXT,
    ecs_no          TEXT,
    ecs_bank        TEXT,
    ecs_ac_no       TEXT,
    ecs_holder      TEXT,
    reg_sl_no       TEXT,
    inv_dp_id       TEXT,
    inv_client_id   TEXT,
    dp_inv_name     TEXT,
    modify_flag     TEXT,
    umrn_code       TEXT,
    upload_batch    TEXT,
    UNIQUE(folio_no, reg_sl_no)
);


            """)
        st.session_state["db_initialized"] = True

        with get_conn() as conn:
            for tbl, col, default in [("holdings", "first_order", "'N'"), ("holdings", "rta", "'Unknown'"),
                                      ("amc_config", "rta", "'Unknown'"), ("amc_schemes", "rta", "'Unknown'")]:
                try:
                    conn.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} TEXT DEFAULT {default}")
                except sqlite3.OperationalError:
                    pass

            conn.executescript("""
                CREATE TABLE IF NOT EXISTS amc_code_map (
                    amc_code TEXT PRIMARY KEY,
                    amc_name TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS cams_brokerage (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    amc_code      TEXT,
                    folio_no      TEXT,
                    scheme_code   TEXT,
                    trxn_no       TEXT,
                    trxn_type     TEXT,
                    brkage_amt    REAL,
                    brkage_type   TEXT,
                    brkage_rate   REAL,
                    inv_name      TEXT,
                    proc_date     TEXT,
                    accrual_month TEXT,
                    plot_amount   REAL,
                    avg_assets    REAL,
                    igst_value    REAL,
                    cgst_value    REAL,
                    sgst_value    REAL,
                    upload_batch  TEXT,
                    UNIQUE (trxn_no, folio_no, accrual_month)
                );
                CREATE TABLE IF NOT EXISTS kfintech_brokerage (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    amc_code      TEXT,
                    folio_no      TEXT,
                    scheme_code   TEXT,
                    trxn_no       TEXT,
                    trxn_type     TEXT,
                    brkage_amt    REAL,
                    brkage_type   TEXT,
                    brkage_rate   REAL,
                    inv_name      TEXT,
                    proc_date     TEXT,
                    accrual_month TEXT,
                    plot_amount   REAL,
                    avg_assets    REAL,
                    igst_value    REAL DEFAULT 0,
                    cgst_value    REAL DEFAULT 0,
                    sgst_value    REAL DEFAULT 0,
                    upload_batch  TEXT,
                    UNIQUE (trxn_no, folio_no, accrual_month)
                );
                CREATE TABLE IF NOT EXISTS cams_aum (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    folio_no        TEXT,
                    inv_name        TEXT,
                    scheme_name     TEXT,
                    amc_code        TEXT,
                    pan_no          TEXT,
                    email           TEXT,
                    rep_date        TEXT,
                    units           REAL,
                    rupee_bal       REAL,
                    upload_batch    TEXT
                );
                
            """)

            try:
                conn.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_cams_aum ON cams_aum (folio_no, scheme_name, rep_date)")
            except sqlite3.OperationalError:
                pass
            try:
                conn.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_kfintech_aum ON kfintech_aum (folio_no, scheme_name, "
                    "rep_date)")
            except sqlite3.OperationalError:
                pass

            try:
                conn.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_monthly_brokerage ON monthly_brokerage (amc, month, year)")
            except sqlite3.OperationalError:
                conn.execute(
                    """DELETE FROM monthly_brokerage WHERE id NOT IN (SELECT MAX(id) FROM monthly_brokerage GROUP BY 
                    amc, month, year)""")
                try:
                    conn.execute(
                        "CREATE UNIQUE INDEX IF NOT EXISTS ux_monthly_brokerage ON monthly_brokerage (amc, month, year)"
                    )
                except sqlite3.OperationalError:
                    pass
                # Add these to the end of init_db()
                conn.executescript("""
                    CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name);
                    CREATE INDEX IF NOT EXISTS idx_clients_pan ON clients(pan);
                    CREATE INDEX IF NOT EXISTS idx_holdings_folio ON holdings(folio_no);
                    CREATE INDEX IF NOT EXISTS idx_holdings_scheme ON holdings(scheme_name);
                    CREATE INDEX IF NOT EXISTS idx_cams_aum_folio ON cams_aum(folio_no);
                    CREATE INDEX IF NOT EXISTS idx_cams_aum_scheme ON cams_aum(scheme_name);
                """)
                # Note: For true performance on leading-wildcard LIKE '%q%', consider migrating to SQLite FTS5 in the future.


# ==================== PURE HELPERS ====================
def clean_str(val) -> str:
    if val is None: return ""
    try:
        if pd.isna(val): return ""
    except (TypeError, ValueError):
        pass
    s = str(val).strip()
    return "" if s.lower() in {"nan", "none", "null", "na", ""} else s


def format_currency(val, decimals: int = 2) -> str:
    try:
        return f"Rs {float(val):,.{decimals}f}"
    except (TypeError, ValueError):
        return "Rs -"


def format_brokerage(val) -> str:
    try:
        amount = float(val)
        formatted = f"{amount:.8f}".rstrip('0').rstrip('.')
        return f"Rs {formatted}"
    except (TypeError, ValueError):
        return "Rs -"


def format_aum(val) -> str:
    try:
        amount = float(val)
        if amount >= 1_00_00_000:
            return f"Rs {amount / 1_00_00_000:.2f} Cr"
        elif amount >= 1_00_000:
            return f"Rs {amount / 1_00_000:.2f} L"
        else:
            return f"Rs {amount:,.0f}"
    except (TypeError, ValueError):
        return "Rs -"


@st.cache_data(show_spinner=False)
def normalize_amc(name: str) -> str:
    if not name: return ""
    n = str(name).strip().upper()
    for suffix in AMC_SUFFIXES: n = n.replace(suffix, "")
    return _WHITESPACE_RE.sub(" ", n).strip()


def get_rta(amc_name: str) -> str:
    norm = normalize_amc(amc_name)
    if norm in CAMS_AMCS: return "CAMS"
    if norm in KFIN_AMCS: return "KFinTech"
    return "Unknown"


def normalize_folio(folio: str) -> str:
    if not folio: return ""
    try:
        if pd.isna(folio): return ""
    except Exception:
        pass
    return str(folio).strip().split("/")[0].strip().lower()


def is_active_status(raw_status) -> bool:
    if pd.isna(raw_status): return True
    status = str(raw_status).strip().upper()
    return not any(kw in status for kw in CANCELLED_KEYWORDS)


def parse_date_safe(val) -> str:
    if pd.isna(val) if isinstance(val, float) else str(val).strip() in {"", "None", "NaN"}: return ""
    try:
        dt = pd.to_datetime(val, dayfirst=True, errors="coerce")
        return dt.strftime("%Y-%m-%d") if pd.notna(dt) else ""
    except Exception:
        return ""


def get_next_sip_date(day) -> str:
    if pd.isna(day) or not day: return "N/A"
    try:
        day = int(day)
        today = datetime.now().date()

        # Try current month
        try:
            candidate = today.replace(day=day)
            if candidate >= today: return candidate.strftime("%d %b %Y")
        except ValueError:
            pass

        # Calculate next month safely
        if today.month == 12:
            next_month = today.replace(year=today.year + 1, month=1, day=1)
        else:
            next_month = today.replace(month=today.month + 1, day=1)

        try:
            return next_month.replace(day=day).strftime("%d %b %Y")
        except ValueError:
            # Fallback to last day of next month
            if next_month.month == 12:
                last_day = next_month.replace(year=next_month.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                last_day = next_month.replace(month=next_month.month + 1, day=1) - timedelta(days=1)
            return last_day.strftime("%d %b %Y")
    except Exception:
        return "N/A"


def theme_plotly(fig, dark: bool):
    """Apply dark/light theming to a Plotly figure."""
    text_c = "#e6edf3" if dark else "#1a1a2e"
    grid_c = "#30363d" if dark else "#e2e8f0"
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font_color=text_c,
        title_font_color=text_c,
        legend_font_color=text_c,
        xaxis=dict(gridcolor=grid_c, linecolor=grid_c),
        yaxis=dict(gridcolor=grid_c, linecolor=grid_c),
    )
    return fig


# ==================== AMFI SYNC ====================
def _amfi_sync_worker(result_bucket: list) -> None:
    try:
        print("[AMFI DEBUG] starting fetch...")
        res = requests.get(AMFI_TEXT_URL, timeout=20)
        print(f"[AMFI DEBUG] status={res.status_code} len={len(res.text)}")
        res.raise_for_status()
        lines = res.text.splitlines()
        print(f"[AMFI DEBUG] {len(lines)} lines received")
        schemes, curr_amc = [], None
        for line in lines:
            ...
        print(f"[AMFI DEBUG] parsed {len(schemes)} schemes before insert")
        if schemes:
            with get_conn() as conn:
                conn.executemany(...)
                ...
            result_bucket.append(("ok", f"Synced {len(schemes):,} schemes"))
        else:
            result_bucket.append(("error", "Parsed 0 schemes — check AMFI URL"))
    except Exception as exc:
        log.exception("AMFI sync failed")
        print(f"[AMFI DEBUG] EXCEPTION: {exc!r}")
        result_bucket.append(("error", str(exc)))


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_amfi_nav_index() -> dict[str, float]:
    try:
        res = requests.get(AMFI_TEXT_URL, timeout=20)
        res.raise_for_status()
        lines = res.text.splitlines()
    except Exception:
        log.exception("AMFI fetch failed")
        return {}

    nav_by_name: dict[str, float] = {}
    for line in lines:
        line = line.strip()
        if not line or ";" not in line:
            continue
        parts = line.split(";")
        if len(parts) < 6 or parts[0] == "Scheme Code":
            continue
        name = parts[3].strip()
        try:
            nav = float(parts[4]) if parts[4] not in ("N.A.", "") else 0.0
        except ValueError:
            nav = 0.0
        if nav > 0 and name:
            key = _WHITESPACE_RE.sub(" ", name.upper())
            nav_by_name[key] = nav
    return nav_by_name


def start_amfi_sync() -> None:
    print(f"[AMFI DEBUG] amfi_sync_started={st.session_state.get('amfi_sync_started')}")

    if st.session_state.get("amfi_sync_started"): return
    st.session_state["amfi_sync_started"] = True
    st.session_state["amfi_result"] = []
    bucket = st.session_state["amfi_result"]
    t = threading.Thread(target=_amfi_sync_worker, args=(bucket,), daemon=True)
    add_script_run_ctx(t)
    t.start()


# ==================== COLUMN NORMALISATION ====================
def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = (df.columns.str.strip().str.lower().str.replace(r"[\s.\-_]+", "_", regex=True))
    return df


# ==================== AUM DATA LOADERS ====================
@st.cache_data(ttl=60, show_spinner=False)
def load_total_aum() -> float:
    with get_conn() as conn:
        result = conn.execute("SELECT COALESCE(SUM(rupee_bal), 0) FROM cams_aum").fetchone()
        return float(result[0]) if result else 0.0


@st.cache_data(ttl=60, show_spinner=False)
def load_total_kfintech_aum() -> float:
    with get_conn() as conn:
        result = conn.execute("SELECT COALESCE(SUM(rupee_bal), 0) FROM kfintech_aum").fetchone()
        return float(result[0]) if result else 0.0


@st.cache_data(ttl=60, show_spinner=False)
def load_combined_total_aum() -> dict:
    cams, kfin = load_total_aum(), load_total_kfintech_aum()
    return {"cams": cams, "kfintech": kfin, "total": cams + kfin}


@st.cache_data(ttl=60, show_spinner=False)
def load_client_aum(client_code: str) -> pd.DataFrame:
    with get_conn() as conn:
        client_folios = conn.execute("SELECT folio_no FROM holdings WHERE client_code = ?", (client_code,)).fetchall()
        pan_row = conn.execute("SELECT pan FROM clients WHERE client_code = ?", (client_code,)).fetchone()
        client_pan = pan_row[0].strip().upper() if pan_row and pan_row[0] else ""
        aum_df = pd.read_sql(
            "SELECT folio_no, inv_name, scheme_name, amc_code, rupee_bal, units, rep_date, pan_no FROM cams_aum", conn)
        if aum_df.empty: return pd.DataFrame()
        aum_df["folio_base"] = aum_df["folio_no"].apply(normalize_folio)
        aum_df["pan_clean"] = aum_df["pan_no"].str.strip().str.upper().fillna("")
        folio_bases = {normalize_folio(f[0]) for f in client_folios if f[0]}
        folio_matched = aum_df[aum_df["folio_base"].isin(folio_bases)].copy()
        folio_matched["match_type"] = "SIP Folio"
        pan_matched = pd.DataFrame()
        if client_pan:
            already_folios = set(folio_matched["folio_no"].str.strip().str.lower())
            pan_rows = aum_df[(aum_df["pan_clean"] == client_pan) & (
                ~aum_df["folio_no"].str.strip().str.lower().isin(already_folios))].copy()
            pan_rows["match_type"] = "Lumpsum (PAN)"
            pan_matched = pan_rows
        result = pd.concat([folio_matched, pan_matched], ignore_index=True)
        return result.drop(columns=["folio_base", "pan_clean", "pan_no"], errors="ignore")


@st.cache_data(ttl=60, show_spinner=False)
def load_client_kfintech_aum(client_code: str) -> pd.DataFrame:
    with get_conn() as conn:
        client_folios = conn.execute("SELECT folio_no FROM holdings WHERE client_code = ?", (client_code,)).fetchall()
        client_row = conn.execute("SELECT pan, email FROM clients WHERE client_code = ?", (client_code,)).fetchone()
        client_email = client_row[1].strip().lower() if client_row and client_row[1] else ""
        aum_df = pd.read_sql(
            "SELECT folio_no, inv_name, scheme_name, amc_code, product_code, scheme_code, dividend_opt, rupee_bal, units, nav, rep_date, email FROM kfintech_aum",
            conn)
        if aum_df.empty: return pd.DataFrame()
        aum_df["folio_base"] = aum_df["folio_no"].apply(normalize_folio)
        aum_df["email_clean"] = aum_df["email"].str.strip().str.lower().fillna("")
        folio_bases = {normalize_folio(f[0]) for f in client_folios if f[0]}
        folio_matched = aum_df[aum_df["folio_base"].isin(folio_bases)].copy()
        folio_matched["match_type"] = "SIP Folio (KFinTech)"
        email_matched = pd.DataFrame()
        if client_email:
            already_folios = set(folio_matched["folio_no"].str.strip().str.lower())
            email_rows = aum_df[(aum_df["email_clean"] == client_email) & (
                ~aum_df["folio_no"].str.strip().str.lower().isin(already_folios))].copy()
            if not email_rows.empty: email_rows["match_type"] = "Lumpsum (Email) (KFinTech)"; email_matched = email_rows
        result = pd.concat([folio_matched, email_matched], ignore_index=True)
        return result.drop(columns=["folio_base", "email_clean"], errors="ignore")


@st.cache_data(ttl=60, show_spinner=False)
def load_combined_client_aum(client_code: str) -> pd.DataFrame:
    cams_df, kfin_df = load_client_aum(client_code), load_client_kfintech_aum(client_code)
    if not cams_df.empty: cams_df["rta_source"] = "CAMS"
    if not kfin_df.empty: kfin_df["rta_source"] = "KFinTech"
    all_cols = list(set(list(cams_df.columns) + list(kfin_df.columns)))
    for col in all_cols:
        if col not in cams_df.columns: cams_df[col] = None
        if col not in kfin_df.columns: kfin_df[col] = None

    # Coerce rupee_bal to numeric to prevent silent 0s on None/strings
    if 'rupee_bal' in cams_df.columns:
        cams_df['rupee_bal'] = pd.to_numeric(cams_df['rupee_bal'], errors='coerce').fillna(0.0)
    if 'rupee_bal' in kfin_df.columns:
        kfin_df['rupee_bal'] = pd.to_numeric(kfin_df['rupee_bal'], errors='coerce').fillna(0.0)
    return pd.concat([cams_df, kfin_df], ignore_index=True) if not (cams_df.empty and kfin_df.empty) else pd.DataFrame()


# ==================== TRANSACTION & NAV LOADERS ====================
@st.cache_data(ttl=60, show_spinner=False)
def load_client_all_transactions(client_code: str) -> pd.DataFrame:
    """Fetches all CAMS and KFinTech transactions for a specific client."""
    with get_conn() as conn:
        # Get client PAN for cross-RTA matching
        client_row = conn.execute(
            "SELECT pan FROM clients WHERE client_code = ?", (client_code,)
        ).fetchone()
        client_pan = client_row[0].strip().upper() if client_row and client_row[0] else ""

        # Collect all possible folio identifiers for this client
        folio_bases = set()

        # From holdings (SIPs)
        for row in conn.execute("SELECT folio_no FROM holdings WHERE client_code = ?", (client_code,)):
            if row[0]:
                folio_bases.add(normalize_folio(row[0]))

        # From CAMS folio master (lumpsums)
        if client_pan:
            for row in conn.execute("SELECT folio_no FROM cams_folio_master WHERE UPPER(TRIM(pan_no)) = ?",
                                    (client_pan,)):
                if row[0]:
                    folio_bases.add(normalize_folio(row[0]))

        # From KFinTech folio master (lumpsums)
        if client_pan:
            for row in conn.execute("SELECT folio_no FROM kfintech_folio_master WHERE UPPER(TRIM(pan_no)) = ?",
                                    (client_pan,)):
                if row[0]:
                    folio_bases.add(normalize_folio(row[0]))

        if not folio_bases:
            return pd.DataFrame()

        # Fetch all transactions
        cams_df = pd.read_sql("""
            SELECT 'CAMS' as RTA, folio_no, scheme_name, scheme_code, trade_date, post_date, 
                   trxn_no, nav, units, amount, trxn_type 
            FROM cams_transactions
        """, conn)

        kfin_df = pd.read_sql("""
            SELECT 'KFinTech' as RTA, folio_no, scheme_name, scheme_code, trade_date, post_date, 
                   trxn_no, nav, units, amount, trxn_type 
            FROM kfintech_transactions
        """, conn)

        all_txns = pd.concat([cams_df, kfin_df], ignore_index=True)
        if all_txns.empty:
            return pd.DataFrame()

        all_txns["folio_base"] = all_txns["folio_no"].apply(normalize_folio)
        return all_txns[all_txns["folio_base"].isin(folio_bases)]


@st.cache_data(ttl=300, show_spinner=False)
def load_amfi_navs() -> dict:
    """Fetches the latest NAV for all schemes from AMFI sync."""
    with get_conn() as conn:
        # Fetch all and filter safely in Python to avoid SQLite type issues
        rows = conn.execute("SELECT scheme_code, last_nav FROM amc_schemes").fetchall()
        nav_dict = {}
        for r in rows:
            try:
                val = float(r[1])
                if val > 0:
                    nav_dict[str(r[0]).strip()] = val
            except (ValueError, TypeError):
                pass  # Skip invalid NAV values
        return nav_dict


@st.cache_data(ttl=300, show_spinner=False)
def load_amfi_navs_by_name() -> dict[str, float]:
    """Builds a mapping from normalized scheme name → NAV."""
    with get_conn() as conn:
        rows = conn.execute("SELECT scheme_name, last_nav FROM amc_schemes").fetchall()
        nav_dict = {}
        for scheme_name, nav in rows:
            try:
                val = float(nav)
                if val > 0 and scheme_name:
                    # Normalize: uppercase, remove extra spaces
                    key = _WHITESPACE_RE.sub(" ", str(scheme_name).strip().upper())
                    nav_dict[key] = val
            except (ValueError, TypeError):
                pass
        return nav_dict


def find_nav_by_scheme_name(scheme_name: str, nav_by_name: dict[str, float]) -> float:
    """Fuzzy match scheme name against AMFI index, respecting Direct/Regular and Growth/IDCW."""
    if not scheme_name:
        return 0.0

    key = _WHITESPACE_RE.sub(" ", str(scheme_name).strip().upper())

    if key in nav_by_name:
        return nav_by_name[key]

    simplified = key.replace(" - ", " ").replace("-", " ")
    if simplified in nav_by_name:
        return nav_by_name[simplified]

    is_direct = "DIRECT" in key
    is_idcw = "IDCW" in key or "DIVIDEND" in key
    want_growth = not is_idcw

    core = re.sub(r"\s*\(.*?\)\s*", " ", key)
    core = re.sub(r"\s*-\s*", " ", core)
    for w in ["GROWTH OPTION", "GROWTH", "IDCW", "DIVIDEND", "DIRECT", "REGULAR", "OPTION", "PLAN"]:
        core = core.replace(w, "")
    core = _WHITESPACE_RE.sub(" ", core).strip()

    if not core:
        return 0.0

    for amfi_name, nav in nav_by_name.items():
        if core not in amfi_name:
            continue
        amfi_is_direct = "DIRECT" in amfi_name
        amfi_is_idcw = "IDCW" in amfi_name or "DIVIDEND" in amfi_name
        if is_direct != amfi_is_direct:
            continue
        if want_growth and amfi_is_idcw:
            continue
        if not want_growth and not amfi_is_idcw:
            continue
        return nav

    return 0.0


# ==================== BROKERAGE DATA LOADERS ====================
@st.cache_data(ttl=60, show_spinner=False)
def load_cams_by_amc(month_str: str) -> pd.DataFrame:
    with get_conn() as conn:
        return pd.read_sql("""
            SELECT cb.amc_code, COALESCE(m.amc_name, h.amc) AS amc_name, cb.accrual_month,
            SUM(cb.brkage_amt) AS cams_brokerage, COUNT(DISTINCT cb.folio_no) AS folio_count
            FROM cams_brokerage cb
            LEFT JOIN amc_code_map m ON UPPER(TRIM(cb.amc_code)) = UPPER(TRIM(m.amc_code))
            LEFT JOIN holdings h ON TRIM(LOWER(cb.folio_no)) = TRIM(LOWER(h.folio_no))
            WHERE cb.accrual_month = ?
            GROUP BY cb.amc_code, COALESCE(m.amc_name, h.amc), cb.accrual_month
        """, conn, params=(month_str,))


@st.cache_data(ttl=60, show_spinner=False)
def load_kfintech_by_amc(month_str: str) -> pd.DataFrame:
    with get_conn() as conn:
        return pd.read_sql("""
            SELECT kb.amc_code, COALESCE(m.amc_name, h.amc) AS amc_name, kb.accrual_month,
            SUM(kb.brkage_amt) AS kfintech_brokerage, COUNT(DISTINCT kb.folio_no) AS folio_count
            FROM kfintech_brokerage kb
            LEFT JOIN amc_code_map m ON UPPER(TRIM(kb.amc_code)) = UPPER(TRIM(m.amc_code))
            LEFT JOIN holdings h ON TRIM(LOWER(kb.folio_no)) = TRIM(LOWER(h.folio_no))
            WHERE kb.accrual_month = ?
            GROUP BY kb.amc_code, COALESCE(m.amc_name, h.amc), kb.accrual_month
        """, conn, params=(month_str,))


@st.cache_data(ttl=60, show_spinner=False)
def load_cams_by_client(client_code: str) -> pd.DataFrame:
    with get_conn() as conn:
        client_folios = conn.execute("SELECT folio_no FROM holdings WHERE client_code = ?", (client_code,)).fetchall()
        client_folio_bases = {normalize_folio(f[0]) for f in client_folios if f[0]}
        if not client_folio_bases: return pd.DataFrame()
        cams_df = pd.read_sql(
            "SELECT accrual_month, amc_code, folio_no, trxn_type, plot_amount, brkage_amt, brkage_rate, inv_name FROM cams_brokerage",
            conn)
        if cams_df.empty: return pd.DataFrame()
        cams_df["folio_base"] = cams_df["folio_no"].apply(normalize_folio)
        cams_matched = cams_df[cams_df["folio_base"].isin(client_folio_bases)].copy()
        if cams_matched.empty: return pd.DataFrame()
        holdings_df = pd.read_sql("SELECT folio_no, scheme_name, amc, rta FROM holdings", conn)
        holdings_df["folio_base"] = holdings_df["folio_no"].apply(normalize_folio)
        # Drop duplicates on folio_base to prevent Cartesian product during merge
        holdings_df = holdings_df.drop_duplicates(subset=["folio_base"])
        merged = cams_matched.merge(holdings_df[["folio_base", "scheme_name", "amc", "rta"]], on="folio_base",
                                    how="left")
        amc_map = load_amc_code_map()
        merged["amc_name"] = merged["amc_code"].map(amc_map).fillna(merged["amc"])
        result = merged.rename(
            columns={"brkage_amt": "brokerage", "plot_amount": "transaction_amount", "brkage_rate": "rate_pct"})
        expected_cols = ["accrual_month", "amc_name", "scheme_name", "folio_no", "trxn_type", "transaction_amount",
                         "brokerage", "rate_pct", "rta"]
        for col in expected_cols:
            if col not in result.columns: result[col] = None
        return result[expected_cols]


@st.cache_data(ttl=60, show_spinner=False)
def load_kfintech_by_client(client_code: str) -> pd.DataFrame:
    with get_conn() as conn:
        client_folios = conn.execute("SELECT folio_no FROM holdings WHERE client_code = ?", (client_code,)).fetchall()
        client_folio_bases = {normalize_folio(f[0]) for f in client_folios if f[0]}
        if not client_folio_bases: return pd.DataFrame()
        kf_df = pd.read_sql(
            "SELECT accrual_month, amc_code, folio_no, trxn_type, plot_amount, brkage_amt, brkage_rate, inv_name FROM kfintech_brokerage",
            conn)
        if kf_df.empty: return pd.DataFrame()
        kf_df["folio_base"] = kf_df["folio_no"].apply(normalize_folio)
        kf_matched = kf_df[kf_df["folio_base"].isin(client_folio_bases)].copy()
        if kf_matched.empty: return pd.DataFrame()
        holdings_df = pd.read_sql("SELECT folio_no, scheme_name, amc, rta FROM holdings", conn)
        holdings_df["folio_base"] = holdings_df["folio_no"].apply(normalize_folio)
        holdings_df = holdings_df.drop_duplicates(subset=["folio_base"])  # <--- ADD THIS
        merged = kf_matched.merge(holdings_df[["folio_base", "scheme_name", "amc", "rta"]], on="folio_base", how="left")
        amc_map = load_amc_code_map()
        merged["amc_name"] = merged["amc_code"].map(amc_map).fillna(merged["amc"])
        result = merged.rename(
            columns={"brkage_amt": "brokerage", "plot_amount": "transaction_amount", "brkage_rate": "rate_pct"})
        expected_cols = ["accrual_month", "amc_name", "scheme_name", "folio_no", "trxn_type", "transaction_amount",
                         "brokerage", "rate_pct", "rta"]
        for col in expected_cols:
            if col not in result.columns: result[col] = None
        return result[expected_cols]


@st.cache_data(ttl=60, show_spinner=False)
def load_cams_months() -> list[str]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT DISTINCT accrual_month FROM cams_brokerage WHERE accrual_month != '' ORDER BY accrual_month DESC").fetchall()
        return [r[0] for r in rows]


@st.cache_data(ttl=60, show_spinner=False)
def load_kfintech_months() -> list[str]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT DISTINCT accrual_month FROM kfintech_brokerage WHERE accrual_month != '' ORDER BY accrual_month DESC").fetchall()
        return [r[0] for r in rows]


@st.cache_data(ttl=60, show_spinner=False)
def load_amc_code_map() -> dict[str, str]:
    with get_conn() as conn:
        rows = conn.execute("SELECT amc_code, amc_name FROM amc_code_map").fetchall()
        return {r[0]: r[1] for r in rows}


@st.cache_data(ttl=60, show_spinner=False)
def load_distinct_all_amc_codes() -> list[str]:
    with get_conn() as conn:
        codes = set()
        # Scan all CAMS tables
        for tbl, col in [("cams_brokerage", "amc_code"), ("cams_aum", "amc_code"),
                         ("cams_transactions", "amc_code"), ("cams_folio_master", "amc_code")]:
            try:
                rows = conn.execute(f"SELECT DISTINCT {col} FROM {tbl} WHERE {col} != ''").fetchall()
                codes.update(r[0].strip() for r in rows if r[0])
            except:
                pass

        # Scan all KFinTech tables (note: KFinTech uses 'fund_code' in some tables)
        for tbl, col in [("kfintech_brokerage", "amc_code"), ("kfintech_aum", "amc_code"),
                         ("kfintech_transactions", "fund_code"), ("kfintech_folio_master", "fund_code")]:
            try:
                rows = conn.execute(f"SELECT DISTINCT {col} FROM {tbl} WHERE {col} != ''").fetchall()
                codes.update(r[0].strip() for r in rows if r[0])
            except:
                pass

        return sorted(list(codes))


@st.cache_data(ttl=60, show_spinner=False)
def load_active_amcs() -> list[str]:
    with get_conn() as conn:
        return [r[0] for r in conn.execute("SELECT amc FROM amc_config WHERE is_enabled = 1").fetchall() if r[0]]


@st.cache_data(ttl=60, show_spinner=False)
def load_active_holdings() -> pd.DataFrame:
    enabled = load_active_amcs()
    if not enabled: return pd.DataFrame()
    enabled_norm = {normalize_amc(a) for a in enabled}
    with get_conn() as conn:
        # Filter directly in SQL using a JOIN with amc_config
        query = """
            SELECT h.* FROM holdings h
            JOIN amc_config ac ON TRIM(UPPER(h.amc)) = TRIM(UPPER(ac.amc))
            WHERE h.status = 'Active' AND ac.is_enabled = 1
        """
        df = pd.read_sql(query, conn)
        if df.empty: return df
        df["rta"] = df["amc"].apply(get_rta)
        return df


@st.cache_data(ttl=300, show_spinner=False)
def load_clients() -> pd.DataFrame:
    with get_conn() as conn: return pd.read_sql("SELECT client_code, name FROM clients ORDER BY name", conn)


@st.cache_data(ttl=300, show_spinner=False)
def load_clients_full() -> pd.DataFrame:
    with get_conn() as conn: return pd.read_sql(
        "SELECT client_code, name, pan, mobile, email FROM clients ORDER BY name", conn)


@st.cache_data(ttl=60, show_spinner=False)
def load_notifications() -> dict:
    today = datetime.now().date()
    week_ahead = today + timedelta(days=7)
    notes = {"sips_due": [], "unmatched_aum": 0, "pending_brokerage": []}
    with get_conn() as conn:
        holdings = pd.read_sql(
            "SELECT h.client_code, c.name, h.scheme_name, h.sip_day FROM holdings h JOIN clients c ON h.client_code = c.client_code WHERE h.status='Active'",
            conn)
        # Vectorize the calculation using pandas
        if not holdings.empty:
            today = datetime.now().date()
            week_ahead = today + timedelta(days=7)

            def calc_next_sip_dt(row):
                day = int(row['sip_day'])
                try:
                    candidate = today.replace(day=day)
                    if candidate >= today: return candidate
                except ValueError:
                    pass

                next_m = today.replace(year=today.year + 1, month=1, day=1) if today.month == 12 else today.replace(
                    month=today.month + 1, day=1)
                try:
                    return next_m.replace(day=day)
                except ValueError:
                    last_m = next_m.replace(year=next_m.year + 1, month=1,
                                            day=1) if next_m.month == 12 else next_m.replace(month=next_m.month + 1,
                                                                                             day=1)
                    return last_m - timedelta(days=1)

            holdings['next_sip_dt'] = holdings.apply(calc_next_sip_dt, axis=1)
            due_sips = holdings[(holdings['next_sip_dt'] >= today) & (holdings['next_sip_dt'] <= week_ahead)]

            for _, row in due_sips.iterrows():
                notes["sips_due"].append({
                    "client": row["name"], "scheme": row["scheme_name"],
                    "date": row["next_sip_dt"].strftime("%d %b %Y")
                })

        # Check CAMS (via PAN) and KFinTech (via Email) separately and sum them
        cams_unmatched = conn.execute("""
            SELECT COUNT(DISTINCT folio_no) FROM cams_aum 
            WHERE folio_no NOT IN (SELECT folio_no FROM holdings) 
            AND (pan_no IS NULL OR pan_no = '' OR pan_no NOT IN (SELECT pan FROM clients WHERE pan IS NOT NULL AND pan != ''))
        """).fetchone()[0]

        kfin_unmatched = conn.execute("""
            SELECT COUNT(DISTINCT folio_no) FROM kfintech_aum 
            WHERE folio_no NOT IN (SELECT folio_no FROM holdings) 
            AND (email IS NULL OR email = '' OR email NOT IN (SELECT email FROM clients WHERE email IS NOT NULL AND email != ''))
        """).fetchone()[0]

        notes["unmatched_aum"] = int(cams_unmatched or 0) + int(kfin_unmatched or 0)
        current_month, current_year = datetime.now().strftime("%b"), datetime.now().year
        active_amc_list = [r[0] for r in
                           conn.execute("SELECT DISTINCT amc FROM holdings WHERE status='Active'").fetchall()]
        entered = {r[0] for r in conn.execute("SELECT amc FROM monthly_brokerage WHERE month=? AND year=?",
                                              (current_month, current_year)).fetchall()}
        notes["pending_brokerage"] = [a for a in active_amc_list if a not in entered]
    return notes


@st.cache_data(ttl=60, show_spinner=False)
def global_search(query: str) -> dict:
    q = query.strip().lower()
    if len(q) < 2: return {}
    results = {}
    with get_conn() as conn:
        clients_df = pd.read_sql(
            "SELECT client_code, name, pan FROM clients WHERE LOWER(name) LIKE ? OR UPPER(pan) LIKE ?", conn,
            params=(f"%{q}%", f"%{query.upper()}%"))
        if not clients_df.empty: results["clients"] = clients_df.to_dict("records")
        folios_df = pd.read_sql(
            "SELECT DISTINCT h.folio_no, h.scheme_name, h.amc, c.name as client_name FROM holdings h LEFT JOIN clients c ON h.client_code = c.client_code WHERE LOWER(h.folio_no) LIKE ? OR LOWER(h.scheme_name) LIKE ?",
            conn, params=(f"%{q}%", f"%{q}%"))
        if not folios_df.empty: results["folios"] = folios_df.to_dict("records")
        aum_df = pd.read_sql(
            "SELECT DISTINCT folio_no, inv_name, scheme_name, pan_no FROM cams_aum WHERE LOWER(folio_no) LIKE ? OR LOWER(scheme_name) LIKE ? OR LOWER(inv_name) LIKE ?",
            conn, params=(f"%{q}%", f"%{q}%", f"%{q}%"))
        if not aum_df.empty: results["aum"] = aum_df.to_dict("records")
    return results


# ==================== APP INIT ====================
st.set_page_config(page_title="MFD Portfolio Intelligence", layout="wide", page_icon="📊")

init_db()
start_amfi_sync()

result_bucket = st.session_state.get("amfi_result", [])
if result_bucket:
    status, msg = result_bucket[0]
    st.toast(f"{'✅' if status == 'ok' else '⚠️'} AMFI: {msg}")
    result_bucket.clear()

# -------------------- THEME (single source of truth) --------------------
if "dark_mode" not in st.session_state:
    st.session_state["dark_mode"] = False
dark = st.session_state["dark_mode"]

_bg = "#0e1117" if dark else "#ffffff"
_sbg = "#161b22" if dark else "#f6f8fa"
_text = "#e6edf3" if dark else "#1a1a2e"
_muted = "#8b949e" if dark else "#6b7280"
_border = "#30363d" if dark else "#d0d7de"
_accent = "#58a6ff" if dark else "#2563eb"

# One consolidated CSS injection – no var(--text-color) conflicts
st.markdown(f"""
<style>
    .stApp {{
        background-color: {_bg} !important;
    }}
    section[data-testid="stSidebar"] {{
        background-color: {_sbg} !important;
    }}
    section[data-testid="stSidebar"] * {{
        color: {_text} !important;
    }}
    .stMarkdown, p, span, div, label,
    [data-testid="stMetricLabel"], [data-testid="stMetricValue"],
    .streamlit-expanderContent, .stAlert,
    .stButton > button, .stTabs button {{
        color: {_text} !important;
    }}
    .stTextInput > div > div > input,
    .stNumberInput > div > div > input,
    .stSelectbox > div > div > div,
    .stRadio > div {{
        background-color: {_sbg} !important;
        color: {_text} !important;
        border-color: {_border} !important;
    }}
    .stDataFrame, .dataframe {{
        color: {_text} !important;
        background: {_sbg} !important;
    }}
    .dataframe th, .dataframe td {{
        color: {_text} !important;
        background: {_sbg} !important;
        border-color: {_border} !important;
    }}
    .main .block-container {{
        padding-top: 0.75rem !important;
        padding-bottom: 1rem !important;
        max-width: 100% !important;
    }}
    .aum-card {{
        background: linear-gradient(135deg, #1a472a 0%, #2d6a4f 100%);
        border-radius: 12px;
        padding: 16px 20px;
        margin-bottom: 8px;
        border: 1px solid rgba(255,255,255,0.1);
    }}
    .aum-card .label {{
        font-size: 0.85rem;
        color: rgba(255,255,255,0.75);
        margin-bottom: 4px;
    }}
    .aum-card .value {{
        font-size: 1.4rem;
        font-weight: 700;
        color: #fff;
    }}
    .aum-card-kfin {{
        background: linear-gradient(135deg, #1a3a5c 0%, #2d6494 100%);
        border-radius: 12px;
        padding: 16px 20px;
        margin-bottom: 8px;
        border: 1px solid rgba(255,255,255,0.1);
    }}
    .aum-card-kfin .label {{
        font-size: 0.85rem;
        color: rgba(255,255,255,0.75);
        margin-bottom: 4px;
    }}
    .aum-card-kfin .value {{
        font-size: 1.4rem;
        font-weight: 700;
        color: #fff;
    }}
    .notif-badge {{
        display:inline-block;
        background:#ef4444;
        color:#fff;
        border-radius:999px;
        font-size:0.7rem;
        font-weight:700;
        padding:1px 7px;
        margin-left:6px;
        vertical-align:middle;
    }}
    .search-card {{
        background:{_sbg};
        border:1px solid {_border};
        border-radius:8px;
        padding:10px 14px;
        margin-bottom:6px;
    }}
    .search-tag {{
        display:inline-block;
        font-size:0.7rem;
        font-weight:600;
        background:{_accent}22;
        color:{_accent};
        border-radius:4px;
        padding:1px 6px;
        margin-right:6px;
    }}
</style>
""", unsafe_allow_html=True)

# -------------------- COMPACT HEADER --------------------
hdr1, hdr2 = st.columns([6, 1])
with hdr1:
    st.markdown("#### 📊 MFD Portfolio Intelligence")
with hdr2:
    if st.button("🌙" if not dark else "☀️", help="Toggle dark/light mode", use_container_width=True):
        st.session_state["dark_mode"] = not st.session_state["dark_mode"]
        st.rerun()
# with hdr3:
#     search_q = st.text_input(
#         "🔍 Global Search", placeholder="Client, folio, scheme…",
#         key="global_search_q", label_visibility="collapsed"
#     )

# Navigation tabs (no heavy dividers)
nav_cols = st.columns([1, 1, 1, 1])
nav_options = ["📊 Dashboard", "👤 Client View", "💰 Earnings", "⚙️ Admin Panel"]
nav_keys = ["nav_dash", "nav_client", "nav_earn", "nav_admin"]
if "nav_mode" not in st.session_state:
    st.session_state["nav_mode"] = "📊 Dashboard"

for i, (opt, key) in enumerate(zip(nav_options, nav_keys)):
    with nav_cols[i]:
        btn_type = "primary" if st.session_state["nav_mode"] == opt else "secondary"
        label = opt.split(' ')[1]
        if st.button(label, key=key, type=btn_type, use_container_width=True):
            st.session_state["nav_mode"] = opt
            st.rerun()

# Handle global search results inline
# if search_q and len(search_q.strip()) >= 2:
#     with st.spinner("Searching…"):
#         sr = global_search(search_q)
#         if not sr:
#             st.caption("No results found.")
#         else:
#             if "clients" in sr:
#                 st.markdown(f"**👤 Clients** ({len(sr['clients'])})")
#                 for r in sr["clients"][:5]: st.markdown(
#                     f'<div class="search-card"><span class="search-tag">Client</span><b>{r["name"]}</b><br><small style="color:{_muted}">{r["pan"] or "—"}</small></div>',
#                     unsafe_allow_html=True)
#             if "folios" in sr:
#                 st.markdown(f"**📂 Folios / Schemes** ({len(sr['folios'])})")
#                 for r in sr["folios"][:5]: st.markdown(
#                     f'<div class="search-card"><span class="search-tag">Folio</span><b>{r["folio_no"]}</b><br><small style="color:{_muted}">{r["scheme_name"][:40]} — {r["client_name"] or "?"}</small></div>',
#                     unsafe_allow_html=True)
#             if "aum" in sr:
#                 st.markdown(f"**📦 AUM Records** ({len(sr['aum'])})")
#                 for r in sr["aum"][:4]: st.markdown(
#                     f'<div class="search-card"><span class="search-tag">AUM</span><b>{r["inv_name"]}</b><br><small style="color:{_muted}">{r["scheme_name"][:40]}</small></div>',
#                     unsafe_allow_html=True)

mode = st.session_state.get("nav_mode", "📊 Dashboard")

df_active = load_active_holdings()
active_amcs_raw = load_active_amcs()

# ==================== 📊 DASHBOARD ====================
if mode == "📊 Dashboard":
    st.header("📊 Portfolio Overview")  # ---- Dashboard-only: Refresh + Notifications ----
    c_refresh, c_notif = st.columns([1, 5])
    with c_refresh:
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.cache_data.clear()
            st.rerun()
    with c_notif:
        notifs = load_notifications()
        n_sips = len(notifs["sips_due"])
        n_unmatched = notifs["unmatched_aum"]
        n_pending = len(notifs["pending_brokerage"])
        total_n = n_sips + (1 if n_unmatched > 0 else 0) + (1 if n_pending > 0 else 0)

        if total_n > 0:
            parts = []
            if n_sips:      parts.append(f"📅 {n_sips} SIPs due")
            if n_unmatched: parts.append(f"⚠️ {n_unmatched} unmatched folios")
            if n_pending:   parts.append(f"⏳ {n_pending} pending brokerage")
            st.caption(" | ".join(parts) + f' <span class="notif-badge">{total_n}</span>', unsafe_allow_html=True)
        else:
            st.caption("✅ All caught up — no pending alerts.")

    # ---- Notification Details Expander (Dashboard only) ----
    if total_n > 0:
        with st.expander("🔔 View Notification Details", expanded=False):
            if n_sips:
                st.markdown(f"**📅 SIPs due in next 7 days** ({n_sips})")
                for s in notifs["sips_due"][:10]:
                    st.caption(f"• {s['client']} — {s['date']} — {s['scheme'][:35]}")
            else:
                st.caption("✅ No SIPs due in next 7 days.")

            if n_unmatched:
                st.markdown(f"**⚠️ Unmatched AUM folios:** {n_unmatched}")
            else:
                st.caption("✅ All AUM folios matched.")

            if n_pending:
                st.markdown(f"**⏳ Brokerage not entered this month** ({n_pending})")
                for a in notifs["pending_brokerage"][:8]:
                    st.caption(f"• {a}")
            else:
                st.caption("✅ All AMC brokerage entered for this month.")

    # ---- Metrics (no RTA filter) ----
    with get_conn() as conn:
        total_brokerage = conn.execute("SELECT COALESCE(SUM(amount), 0) FROM monthly_brokerage").fetchone()[0]
        total_clients = conn.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
    aum_data = load_combined_total_aum()
    total_aum, cams_aum, kfin_aum = aum_data["total"], aum_data["cams"], aum_data["kfintech"]
    sip_count = len(df_active)
    sip_total = df_active["sip_amount"].sum() if not df_active.empty else 0
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("👥 Clients", total_clients)
    m2.metric("📈 Active SIPs", sip_count)
    m3.metric("💰 Monthly SIP", format_currency(sip_total, decimals=0))
    m4.metric("🏢 Enabled AMCs", len(active_amcs_raw))
    m5.metric("💵 Brokerage Rcvd.", format_currency(total_brokerage, decimals=0))
    if total_aum > 0:
        aum_col1, aum_col2, aum_col3, aum_col4 = st.columns([1, 1, 1, 1])
        with aum_col1:
            st.markdown(
                f"""<div class="aum-card"><div class="label">📦 Total AUM (All RTAs)</div><div class="value">{format_aum(total_aum)}</div></div>""",
                unsafe_allow_html=True)
        with aum_col2:
            st.markdown(
                f"""<div class="aum-card" style="background: linear-gradient(135deg, #1a3a5c 0%, #2d6494 100%);"><div class="label">📦 CAMS AUM</div><div class="value">{format_aum(cams_aum)}</div></div>""",
                unsafe_allow_html=True)
        with aum_col3:
            st.markdown(
                f"""<div class="aum-card-kfin"><div class="label">📦 KFinTech AUM</div><div class="value">{format_aum(kfin_aum)}</div></div>""",
                unsafe_allow_html=True)
        with aum_col4:
            with get_conn() as conn:
                aum_schemes = conn.execute(
                    "SELECT COUNT(DISTINCT scheme_name) FROM (SELECT scheme_name FROM cams_aum UNION SELECT scheme_name FROM kfintech_aum)").fetchone()[
                    0]
                aum_folios = conn.execute(
                    "SELECT COUNT(DISTINCT folio_no) FROM (SELECT folio_no FROM cams_aum UNION SELECT folio_no FROM kfintech_aum)").fetchone()[
                    0]
            st.markdown(
                f"""<div class="aum-card" style="background: linear-gradient(135deg, #5c1a3a 0%, #942d64 100%);"><div class="label">📂 Schemes × Folios</div><div class="value">{aum_schemes} × {aum_folios}</div></div>""",
                unsafe_allow_html=True)
    else:
        st.info("📦 Upload CAMS or KFinTech AUM Report in Admin Panel → Import RTA Data to see Total AUM.")
    st.divider()
    if df_active.empty:
        st.warning("📭 No Active Holdings Found.")
    else:
        c1, c2 = st.columns(2)
        amc_grp = df_active.groupby("amc")["sip_amount"].sum().reset_index()
        with c1:
            fig = px.pie(amc_grp, values="sip_amount", names="amc", hole=0.4,
                         title="SIP Distribution by AMC (All)")
            fig = theme_plotly(fig, dark)
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            fig = px.bar(amc_grp, x="amc", y="sip_amount", labels={"amc": "AMC", "sip_amount": "Monthly SIP (Rs)"},
                         title="Monthly SIP by AMC (All)")
            fig = theme_plotly(fig, dark)
            st.plotly_chart(fig, use_container_width=True)
        if total_aum > 0:
            st.subheader("📦 AUM Breakdown")

            # Radio button to toggle the view
            view_by = st.radio(
                "View AUM by:",
                ["AMC", "Schemes", "Clients"],
                horizontal=True,
                key="aum_view_by_radio"
            )

            with get_conn() as conn:
                if view_by == "AMC":
                    query = """
                        SELECT COALESCE(m.amc_name, a.amc_code) as Name, SUM(a.rupee_bal) as AUM 
                        FROM cams_aum a LEFT JOIN amc_code_map m ON UPPER(TRIM(a.amc_code)) = UPPER(TRIM(m.amc_code)) 
                        GROUP BY COALESCE(m.amc_name, a.amc_code)
                        UNION ALL
                        SELECT COALESCE(m.amc_name, a.amc_code) as Name, SUM(a.rupee_bal) as AUM 
                        FROM kfintech_aum a LEFT JOIN amc_code_map m ON UPPER(TRIM(a.amc_code)) = UPPER(TRIM(m.amc_code)) 
                        GROUP BY COALESCE(m.amc_name, a.amc_code)
                    """
                elif view_by == "Schemes":
                    query = """
                        SELECT scheme_name as Name, SUM(rupee_bal) as AUM 
                        FROM cams_aum GROUP BY scheme_name
                        UNION ALL
                        SELECT scheme_name as Name, SUM(rupee_bal) as AUM 
                        FROM kfintech_aum GROUP BY scheme_name
                    """
                else:  # Clients
                    query = """
                    SELECT c.name as Name, SUM(a.rupee_bal) as AUM
                    FROM cams_aum a
                    JOIN clients c ON (
                        TRIM(LOWER(SUBSTR(a.folio_no, 1, INSTR(a.folio_no || '/', '/') - 1))) IN 
                            (SELECT TRIM(LOWER(SUBSTR(folio_no, 1, INSTR(folio_no || '/', '/') - 1))) FROM holdings WHERE client_code = c.client_code)
                        OR TRIM(UPPER(a.pan_no)) = TRIM(UPPER(c.pan))
                        OR TRIM(LOWER(a.email)) = TRIM(LOWER(c.email))
                    )
                    GROUP BY c.name
                    UNION ALL
                    SELECT c.name as Name, SUM(a.rupee_bal) as AUM
                    FROM kfintech_aum a
                    JOIN clients c ON (
                        TRIM(LOWER(SUBSTR(a.folio_no, 1, INSTR(a.folio_no || '/', '/') - 1))) IN 
                            (SELECT TRIM(LOWER(SUBSTR(folio_no, 1, INSTR(folio_no || '/', '/') - 1))) FROM holdings WHERE client_code = c.client_code)
                        OR TRIM(LOWER(a.email)) = TRIM(LOWER(c.email))
                    )
                    GROUP BY c.name
                    """

                df_aum_raw = pd.read_sql(query, conn)

            if not df_aum_raw.empty:
                df_aum_raw['Name'] = df_aum_raw['Name'].fillna('Unknown')

                # Combine CAMS and KFinTech
                df_summary = df_aum_raw.groupby('Name', as_index=False)['AUM'].sum()
                df_summary = df_summary.sort_values(by='AUM', ascending=False).reset_index(drop=True)

                # Calculate total before formatting
                total_list_aum = df_summary['AUM'].sum()

                # Format for display
                df_summary['AUM_Display'] = df_summary['AUM'].apply(format_aum)

                # Rename columns based on the selected view
                name_col = 'AMC Name' if view_by == "AMC" else (
                    'Scheme Name' if view_by == "Schemes" else 'Client Name')
                display_df = df_summary[['Name', 'AUM_Display']].rename(
                    columns={'Name': name_col, 'AUM_Display': 'Total AUM'})

                # Display the main summary table
                st.dataframe(display_df, use_container_width=True, hide_index=True)
                st.metric(f"📊 Total {view_by} AUM", format_aum(total_list_aum))

                # ==========================================
                # 🚀 NEW: DRILL-DOWN SECTION
                # ==========================================
                st.divider()
                st.subheader(f"🔍 Drill Down: {view_by}")

                # Get clean list of names for the dropdown
                entity_names = df_summary['Name'].tolist()
                singular_name = "AMC" if view_by == "AMC" else view_by[:-1]  # AMC, Scheme, Client

                selected_entity = st.selectbox(
                    f"Select a {singular_name} to view underlying details:",
                    entity_names,
                    key=f"drilldown_select_{view_by}"
                )

                if selected_entity:
                    with st.spinner("Fetching details..."):
                        with get_conn() as conn:
                            if view_by == "AMC":
                                # AMC -> Schemes
                                drill_query = """
                                    SELECT scheme_name as "Scheme Name", SUM(rupee_bal) as AUM
                                    FROM (
                                        SELECT a.scheme_name, a.rupee_bal, COALESCE(m.amc_name, a.amc_code) as amc_display
                                        FROM cams_aum a LEFT JOIN amc_code_map m ON UPPER(TRIM(a.amc_code)) = UPPER(TRIM(m.amc_code))
                                        UNION ALL
                                        SELECT a.scheme_name, a.rupee_bal, COALESCE(m.amc_name, a.amc_code) as amc_display
                                        FROM kfintech_aum a LEFT JOIN amc_code_map m ON UPPER(TRIM(a.amc_code)) = UPPER(TRIM(m.amc_code))
                                    )
                                    WHERE amc_display = ?
                                    GROUP BY scheme_name
                                    ORDER BY AUM DESC
                                """
                                drill_df = pd.read_sql(drill_query, conn, params=(selected_entity,))

                            elif view_by == "Schemes":
                                # Scheme -> Clients
                                drill_query = """
                                    SELECT c.name as "Client Name", SUM(a.rupee_bal) as AUM
                                    FROM (
                                        SELECT folio_no, rupee_bal, scheme_name FROM cams_aum
                                        UNION ALL
                                        SELECT folio_no, rupee_bal, scheme_name FROM kfintech_aum
                                    ) a
                                    JOIN holdings h ON TRIM(LOWER(SUBSTR(a.folio_no, 1, INSTR(a.folio_no || '/', '/') - 1))) = 
                 TRIM(LOWER(SUBSTR(h.folio_no, 1, INSTR(h.folio_no || '/', '/') - 1)))
                                    JOIN clients c ON h.client_code = c.client_code
                                    WHERE a.scheme_name = ?
                                    GROUP BY c.name
                                    ORDER BY AUM DESC
                                """
                                drill_df = pd.read_sql(drill_query, conn, params=(selected_entity,))

                            else:
                                # Client -> Schemes (Includes AMC Name for better context!)
                                drill_query = """
                                    SELECT 
                                        COALESCE(m.amc_name, a.amc_code) as "AMC Name", 
                                        a.scheme_name as "Scheme Name", 
                                        SUM(a.rupee_bal) as AUM
                                    FROM (
                                        SELECT folio_no, scheme_name, rupee_bal, amc_code FROM cams_aum
                                        UNION ALL
                                        SELECT folio_no, scheme_name, rupee_bal, amc_code FROM kfintech_aum
                                    ) a
                                    JOIN holdings h ON TRIM(LOWER(SUBSTR(a.folio_no, 1, INSTR(a.folio_no || '/', '/') - 1))) = 
                 TRIM(LOWER(SUBSTR(h.folio_no, 1, INSTR(h.folio_no || '/', '/') - 1)))
                                    JOIN clients c ON h.client_code = c.client_code
                                    LEFT JOIN amc_code_map m ON UPPER(TRIM(a.amc_code)) = UPPER(TRIM(m.amc_code))
                                    WHERE c.name = ?
                                    GROUP BY COALESCE(m.amc_name, a.amc_code), a.scheme_name
                                    ORDER BY AUM DESC
                                """
                                drill_df = pd.read_sql(drill_query, conn, params=(selected_entity,))

                        if not drill_df.empty:
                            # Calculate total for this specific drill-down
                            drill_total = drill_df['AUM'].sum()

                            # Format AUM column
                            drill_df['AUM'] = drill_df['AUM'].apply(format_aum)

                            # Display the drill-down table
                            st.dataframe(drill_df, use_container_width=True, hide_index=True)
                            st.caption(f"💰 Total AUM for **{selected_entity}**: {format_aum(drill_total)}")
                        else:
                            st.info(f"No underlying AUM data found for {selected_entity}.")
            else:
                st.info(f"No AUM data found for {view_by}.")
        csv = amc_grp.to_csv(index=False).encode()
        st.download_button("⬇️ Export AMC Summary (CSV)", csv, "amc_summary_all.csv", "text/csv")


# ==================== 👤 CLIENT VIEW ====================
elif mode == "👤 Client View":
    st.header("👤 Client Portfolio")
    clients = load_clients()

    if clients.empty:
        st.warning("No clients imported.")
    else:
        # --- 1. Client Search ---
        # Streamlit's selectbox has a built-in search/filter feature when you type in it.
        sel = st.selectbox(
            "🔍 Select Client (Type to search)",
            clients["name"].tolist(),
            index=None,
            placeholder="Search client name...",
            key="client_selectbox"
        )

        # --- 2. Client Details (If selected) ---
        if sel:
            code = clients.loc[clients["name"] == sel, "client_code"].iloc[0]
            c_holdings = df_active[df_active["client_code"] == code].copy()
            client_aum_df = load_combined_client_aum(code)

            total_invested = client_aum_df["rupee_bal"].sum() if not client_aum_df.empty else 0.0
            cams_aum_df, kfin_aum_df = load_client_aum(code), load_client_kfintech_aum(code)
            has_sips, has_aum = not c_holdings.empty, not client_aum_df.empty
            has_cams, has_kfin = not cams_aum_df.empty, not kfin_aum_df.empty

            if has_sips:
                c_holdings["next_sip"] = c_holdings["sip_day"].apply(get_next_sip_date)
                next_dates = pd.to_datetime(c_holdings["next_sip"], format="%d %b %Y", errors="coerce")
                next_sip_dt = next_dates.min()
                sip_total_amt = c_holdings["sip_amount"].sum()
                next_sip_str = next_sip_dt.strftime("%d %b %Y") if pd.notna(next_sip_dt) else "N/A"
            else:
                sip_total_amt, next_sip_str = 0.0, "—"

            st.divider()
            st.subheader("📊 Client Summary")
            m1, m2, m3, m4, m5 = st.columns(5)
            m1.metric("📈 Active SIPs", len(c_holdings) if has_sips else 0)
            m2.metric("💰 Monthly SIP", format_currency(sip_total_amt, decimals=0))
            m3.metric("📅 Next SIP", next_sip_str)
            m4.metric("📦 Total AUM", format_aum(total_invested) if total_invested > 0 else "—")
            m5.metric("📦 RTAs", (
                "CAMS+KFin" if (has_cams and has_kfin) else ("CAMS" if has_cams else ("KFin" if has_kfin else "—"))))

            if has_sips:
                st.subheader("📋 Active SIPs")
                display_df = c_holdings[
                    ["scheme_name", "amc", "rta", "folio_no", "sip_amount", "start_date", "next_sip",
                     "first_order"]].copy()
                display_df["Start Date"] = pd.to_datetime(display_df["start_date"], errors="coerce").dt.strftime(
                    "%d %b %Y")
                display_df["SIP Amt"] = display_df["sip_amount"].apply(lambda x: format_currency(x, decimals=0))
                display_df["First Order"] = display_df["first_order"].apply(
                    lambda x: "Yes" if str(x).upper() == "Y" else "No")

                total_rows = len(display_df)
                page = st.number_input("Page", 1, max(1, -(-total_rows // PAGE_SIZE)), 1)
                start, end = (page - 1) * PAGE_SIZE, page * PAGE_SIZE
                st.caption(f"Showing {start + 1}–{min(end, total_rows)} of {total_rows} SIPs")
                st.dataframe(display_df.iloc[start:end][
                    ["scheme_name", "amc", "rta", "folio_no", "SIP Amt", "Start Date", "next_sip",
                     "First Order"]].rename(
                    columns={"scheme_name": "Scheme", "amc": "AMC", "rta": "RTA", "folio_no": "Folio",
                             "next_sip": "Next SIP"}),
                    use_container_width=True, hide_index=True)

            # ==========================================
            # 🚀 HOLDINGS & TRANSACTIONS SECTION
            # ==========================================
            st.divider()
            st.subheader("📂 Holdings & Transaction History")
            st.caption(
                "Calculated from uploaded CAMS & KFinTech Transaction files. Current Value uses latest AMFI NAV.")

            txns_df = load_client_all_transactions(code)
            amfi_navs = load_amfi_navs()  # Uses the fixed function above

            amfi_navs_by_name = fetch_amfi_nav_index()

            if txns_df.empty:
                st.info(
                    "No transaction history found for this client. Please upload CAMS/KFinTech Transaction files in the Admin Panel.")
            else:
                # Ensure numeric columns
                txns_df["units"] = pd.to_numeric(txns_df["units"], errors="coerce").fillna(0)
                txns_df["amount"] = pd.to_numeric(txns_df["amount"], errors="coerce").fillna(0)
                txns_df["nav"] = pd.to_numeric(txns_df["nav"], errors="coerce").fillna(0)
                txns_df["scheme_code"] = txns_df["scheme_code"].astype(str).str.strip()

                # Calculate Holdings Summary (Grouped by Scheme)
                holdings_summary = txns_df.groupby(["scheme_name", "scheme_code"]).agg(
                    Total_Units=("units", "sum"),
                    Invested_Value=("amount", "sum")  # Net invested (Purchases - Redemptions)
                ).reset_index()

                # Calculate Current Value using AMFI NAV


                def get_current_nav(scheme_name: str) -> float:
                    return find_nav_by_scheme_name(scheme_name, amfi_navs_by_name)


                holdings_summary["nav_used"] = holdings_summary["scheme_name"].apply(
                    lambda s: find_nav_by_scheme_name(s, amfi_navs_by_name)
                )
                holdings_summary["Current_Value"] = holdings_summary["Total_Units"] * holdings_summary["nav_used"]

                # Sort by Current Value descending
                holdings_summary = holdings_summary.sort_values(by="Current_Value", ascending=False)

                # Display Summary Table
                summary_display = holdings_summary[
                    ["scheme_name", "Total_Units", "Invested_Value", "Current_Value"]].copy()
                summary_display["Total_Units"] = summary_display["Total_Units"].apply(lambda x: f"{x:,.3f}")
                summary_display["Invested_Value"] = summary_display["Invested_Value"].apply(
                    lambda x: format_currency(x, 2))
                summary_display["Current_Value"] = summary_display["Current_Value"].apply(
                    lambda x: format_currency(x, 2))
                summary_display.columns = ["Scheme Name", "Total Units", "Invested Value (Net)", "Current Value (AMFI)"]

                st.dataframe(summary_display, use_container_width=True, hide_index=True)

                # Totals
                tot_units = holdings_summary["Total_Units"].sum()
                tot_inv = holdings_summary["Invested_Value"].sum()
                tot_cur = holdings_summary["Current_Value"].sum()
                tc1, tc2, tc3 = st.columns(3)
                tc1.metric("Total Units", f"{tot_units:,.3f}")
                tc2.metric("Total Invested", format_currency(tot_inv, 2))
                tc3.metric("Total Current", format_currency(tot_cur, 2))

                st.divider()

                # --- Expandable Transaction Details ---
                folio_search = st.text_input("🔍 Filter Transactions by Folio Number", key="folio_search_txn")

                for _, row in holdings_summary.iterrows():
                    scheme = row["scheme_name"]
                    scheme_txns = txns_df[txns_df["scheme_name"] == scheme].copy()

                    # Apply folio filter if search term exists
                    if folio_search:
                        scheme_txns = scheme_txns[
                            scheme_txns["folio_no"].str.contains(folio_search, case=False, na=False)]

                    if not scheme_txns.empty:
                        # Expander header with quick stats
                        expander_label = f"📊 {scheme}  |  Units: {row['Total_Units']:,.3f}  |  Current: {format_currency(row['Current_Value'], 2)}"

                        with st.expander(expander_label):
                            # Format transaction table
                            disp_txns = scheme_txns[
                                ["trade_date", "post_date", "trxn_no", "nav", "units", "amount", "trxn_type",
                                 "folio_no", "RTA"]].copy()
                            disp_txns["trade_date"] = pd.to_datetime(disp_txns["trade_date"],
                                                                     errors="coerce").dt.strftime("%d-%b-%Y")
                            disp_txns["post_date"] = pd.to_datetime(disp_txns["post_date"],
                                                                    errors="coerce").dt.strftime("%d-%b-%Y")
                            disp_txns["nav"] = disp_txns["nav"].apply(lambda x: f"₹{x:,.4f}")
                            disp_txns["units"] = disp_txns["units"].apply(lambda x: f"{x:,.3f}")
                            disp_txns["amount"] = disp_txns["amount"].apply(lambda x: format_currency(x, 2))

                            disp_txns.columns = ["Trade Date", "Post Date", "Txn No", "NAV", "Units", "Amount", "Type",
                                                 "Folio No", "RTA"]
                            st.dataframe(disp_txns, use_container_width=True, hide_index=True)

            # --- Brokerage Section (Existing) ---
            st.divider()
            st.subheader("💹 Brokerage Generated (from RTA Files)")
            cams_client = load_cams_by_client(code)
            kf_client = load_kfintech_by_client(code)
            all_client_brok = pd.concat([cams_client, kf_client], ignore_index=True) if not (
                    cams_client.empty and kf_client.empty) else pd.DataFrame()

            if all_client_brok.empty:
                st.info("No RTA brokerage data found for this client's folios.")
            else:
                months_avail = sorted(all_client_brok["accrual_month"].unique(), reverse=True)
                sel_month = st.selectbox("📅 Filter by Accrual Month", ["All"] + months_avail, key=f"brok_filter_{code}")
                view_df = all_client_brok if sel_month == "All" else all_client_brok[
                    all_client_brok["accrual_month"] == sel_month]

                total_brok = view_df["brokerage"].sum()
                bm1, bm2 = st.columns(2)
                bm1.metric("💰 Total Brokerage", format_brokerage(total_brok))
                bm2.metric("📅 Months Shown", len(view_df["accrual_month"].unique()))

                disp = view_df[
                    ["accrual_month", "amc_name", "scheme_name", "folio_no", "trxn_type", "transaction_amount",
                     "brokerage", "rate_pct", "rta"]].copy()
                disp["transaction_amount"] = disp["transaction_amount"].apply(lambda x: format_currency(x, decimals=0))
                disp["brokerage"] = disp["brokerage"].apply(format_brokerage)
                disp["rate_pct"] = disp["rate_pct"].apply(lambda x: f"{float(x):,.4f}%" if x else "-")
                disp.columns = ["Month", "AMC", "Scheme", "Folio", "Txn Type", "Txn Amount", "Brokerage", "Rate", "RTA"]
                st.dataframe(disp, use_container_width=True, hide_index=True)


# ==================== 💰 EARNINGS ====================
elif mode == "💰 Earnings":
    st.header("💰 Brokerage Earnings")
    client_amcs = sorted(df_active["amc"].unique().tolist()) if not df_active.empty else []
    if not client_amcs:
        st.info("No active SIPs to record brokerage for.")
    else:
        current_month, current_year = datetime.now().strftime("%b"), datetime.now().year
        st.subheader("📝 Record / Update Brokerage")
        with st.container():
            c1, c2, c3 = st.columns(3)
            sel_amc = c1.selectbox("AMC", client_amcs, index=None, placeholder="Choose AMC...")
            month = c2.selectbox("Month", MONTHS, index=MONTHS.index(current_month))
            year = c3.number_input("Year", 2024, 2030, current_year)
            amt = st.number_input("Brokerage Amount (Rs)", min_value=0.0, step=0.01)
            notes = st.text_input("Notes (optional)")
            col_save, col_del = st.columns([1, 1])
            if col_save.button("💾 Save / Update"):
                if not sel_amc:
                    st.error("Select an AMC first.")
                else:
                    with get_conn() as conn:
                        conn.execute(
                            "INSERT INTO monthly_brokerage (amc, month, year, amount, notes) VALUES (?,?,?,?,?) ON CONFLICT(amc, month, year) DO UPDATE SET amount=excluded.amount, notes=excluded.notes",
                            (sel_amc, month, year, amt, notes))
                    st.success(f"Rs {amt:,.2f} saved for {sel_amc} — {month} {year}")
                    st.cache_data.clear()
                    st.rerun()
            if col_del.button("🗑️ Delete Entry"):
                if not sel_amc:
                    st.error("Select an AMC first.")
                else:
                    with get_conn() as conn:
                        conn.execute("DELETE FROM monthly_brokerage WHERE amc=? AND month=? AND year=?",
                                     (sel_amc, month, year))
                    st.success(f"Deleted entry for {sel_amc} — {month} {year}")
                    st.cache_data.clear()
                    st.rerun()
        st.divider()
        st.subheader("📊 Brokerage Reconciliation")
        all_rta_months = sorted(list(set(load_cams_months() + load_kfintech_months())), reverse=True)
        curr_ym = f"{current_year}-{datetime.now().month:02d}"
        if curr_ym not in all_rta_months: all_rta_months.append(curr_ym)
        all_rta_months = sorted(all_rta_months, reverse=True)
        sel_ym = st.selectbox("📅 Select Reconciliation Month", all_rta_months,
                              format_func=lambda x: datetime(*map(int, x.split("-")), 1).strftime(
                                  "%B %Y") if "-" in x else x,
                              index=all_rta_months.index(curr_ym) if curr_ym in all_rta_months else 0)
        sel_year, sel_month_num = map(int, sel_ym.split("-"))
        sel_month_str = datetime(sel_year, sel_month_num, 1).strftime("%b")
        with get_conn() as conn:
            brok_df = pd.read_sql("SELECT amc, amount FROM monthly_brokerage WHERE month=? AND year=?", conn,
                                  params=(sel_month_str, sel_year))
            brok_map = dict(zip(brok_df["amc"], brok_df["amount"])) if not brok_df.empty else {}
        cams_amc_df = load_cams_by_amc(sel_ym)
        cams_map = {}
        if not cams_amc_df.empty:
            for _, r in cams_amc_df.iterrows():
                key = r["amc_name"] or r["amc_code"] or ""
                if key: cams_map[key] = cams_map.get(key, 0.0) + float(r["cams_brokerage"] or 0)
        kfintech_amc_df = load_kfintech_by_amc(sel_ym)
        kfintech_map = {}
        if not kfintech_amc_df.empty:
            for _, r in kfintech_amc_df.iterrows():
                key = r["amc_name"] or r["amc_code"] or ""
                if key: kfintech_map[key] = kfintech_map.get(key, 0.0) + float(r["kfintech_brokerage"] or 0)
        table_data, total_manual, total_cams_sum, total_kf_sum = [], 0.0, 0.0, 0.0
        for amc in client_amcs:
            sip_ct = int((df_active["amc"] == amc).sum())
            sip_vol = float(df_active.loc[df_active["amc"] == amc, "sip_amount"].sum())
            manual = brok_map.get(amc)
            cams_val, kfintech_val = cams_map.get(amc, 0.0), kfintech_map.get(amc, 0.0)
            total_file_val = cams_val + kfintech_val
            if manual is not None:
                status = "✅ Entered"
                total_manual += manual
            else:
                manual = 0.0
                status = "⏳ Pending"
            total_cams_sum += cams_val
            total_kf_sum += kfintech_val
            diff = manual - total_file_val if (manual and total_file_val) else None
            diff_str = format_brokerage(diff) if diff is not None else "—"
            match_icon = ("✅" if abs(diff) < 10 else "⚠️") if diff is not None else "—"
            table_data.append({
                "AMC": amc, "SIP Count": sip_ct, "Monthly Volume": format_currency(sip_vol, decimals=0),
                "Manual Entry": format_currency(manual, decimals=2),
                "CAMS File": format_brokerage(cams_val) if cams_val else "—",
                "KFinTech File": format_brokerage(kfintech_val) if kfintech_val else "—",
                "Total File": format_brokerage(total_file_val) if total_file_val else "—",
                "Difference": diff_str, "Match": match_icon, "Status": status,
            })
        st.dataframe(pd.DataFrame(table_data), use_container_width=True, hide_index=True)
        tm1, tm2, tm3 = st.columns(3)
        tm1.metric("💵 Total Manual", format_currency(total_manual, decimals=2))
        tm2.metric("📄 Total RTA File", format_brokerage(total_cams_sum + total_kf_sum))
        tm3.metric("↔️ Difference", format_brokerage(total_manual - (total_cams_sum + total_kf_sum)))

        if all_rta_months:
            st.divider()
            st.subheader("📅 RTA Brokerage — By Accrual Month")
            sel_rta_month = st.selectbox("Accrual Month", all_rta_months, key="earnings_rta_month")
            month_df_cams = load_cams_by_amc(sel_rta_month)
            month_df_kf = load_kfintech_by_amc(sel_rta_month)
            if not month_df_cams.empty and not month_df_kf.empty:
                month_df = pd.merge(month_df_cams, month_df_kf, on=["amc_code", "amc_name", "accrual_month"],
                                    how="outer").fillna(0)
                month_df["total_brokerage"] = month_df["cams_brokerage"] + month_df["kfintech_brokerage"]
            elif not month_df_cams.empty:
                month_df = month_df_cams
                month_df["kfintech_brokerage"] = 0
                month_df["total_brokerage"] = month_df["cams_brokerage"]
            elif not month_df_kf.empty:
                month_df = month_df_kf
                month_df["cams_brokerage"] = 0
                month_df["total_brokerage"] = month_df["kfintech_brokerage"]
            else:
                month_df = pd.DataFrame()
            if not month_df.empty:
                month_df["cams_brokerage"] = month_df["cams_brokerage"].apply(format_brokerage)
                month_df["kfintech_brokerage"] = month_df["kfintech_brokerage"].apply(format_brokerage)
                month_df["total_brokerage"] = month_df["total_brokerage"].apply(format_brokerage)
                st.dataframe(month_df.rename(
                    columns={"amc_code": "AMC Code", "amc_name": "AMC Name", "cams_brokerage": "CAMS Brokerage",
                             "kfintech_brokerage": "KFinTech Brokerage", "total_brokerage": "Total Brokerage",
                             "folio_count": "Folios", "accrual_month": "Month"}), use_container_width=True,
                    hide_index=True)
        csv = pd.DataFrame(table_data).to_csv(index=False).encode()
        st.download_button("⬇️ Export Earnings (CSV)", csv, f"brokerage_{sel_month_str}_{sel_year}.csv", "text/csv")

        # AMC-Wise Brokerage Breakdown
        st.divider()
        st.subheader("📈 AMC-wise Brokerage Breakdown (All Time)")
        st.caption("View total brokerage earned per AMC from manual entries AND uploaded files")
        col1, col2, col3 = st.columns(3)
        with col1:
            breakdown_rta = st.selectbox("RTA", ["All", "CAMS", "KFinTech", "Unknown"], key="breakdown_rta")
        with col2:
            breakdown_sort = st.selectbox("Sort By", ["AMC Name", "Manual Total", "File Total", "Difference"],
                                          key="breakdown_sort")
        with col3:
            breakdown_search = st.text_input("🔍 Search AMC", "", key="breakdown_search")

        # Load manual entries
        with get_conn() as conn:
            manual_all = pd.read_sql(
                "SELECT amc, SUM(amount) as total_manual FROM monthly_brokerage GROUP BY amc",
                conn
            )
        manual_map = dict(zip(manual_all["amc"], manual_all["total_manual"])) if not manual_all.empty else {}

        # Load file-based (CAMS) brokerage and keep file_all in scope
        with get_conn() as conn:
            file_all = pd.read_sql("""
                SELECT
                    COALESCE(m.amc_name, h.amc) as amc_name,
                    cb.amc_code,
                    SUM(cb.brkage_amt) as total_file
                FROM cams_brokerage cb
                LEFT JOIN amc_code_map m ON UPPER(TRIM(cb.amc_code)) = UPPER(TRIM(m.amc_code))
                LEFT JOIN holdings h ON TRIM(LOWER(cb.folio_no)) = TRIM(LOWER(h.folio_no))
                GROUP BY COALESCE(m.amc_name, h.amc), cb.amc_code
            """, conn)

        file_map: dict[str, float] = {}
        if not file_all.empty:
            for _, r in file_all.iterrows():
                key = r["amc_name"] or r["amc_code"] or ""
                if key:
                    file_map[key] = file_map.get(key, 0.0) + float(r["total_file"] or 0)

        cams_months_list = load_cams_months()

        breakdown_data = []
        for amc in sorted(set(list(manual_map.keys()) + list(file_map.keys()) + client_amcs)):
            if breakdown_rta != "All":
                amc_rta = df_active[df_active["amc"] == amc]["rta"].iloc[0] if amc in df_active[
                    "amc"].values else "Unknown"
                if amc_rta != breakdown_rta:
                    continue
            if breakdown_search and breakdown_search.lower() not in amc.lower():
                continue

            manual_val = manual_map.get(amc, 0.0)
            file_val = file_map.get(amc, 0.0)
            diff = manual_val - file_val
            match_status = "✅ Match" if abs(diff) < 10 else ("⚠️ Gap" if diff != 0 else "—")

            # Precompute actual distinct months before the loop
            file_months_map = {}
            with get_conn() as conn:
                for row in conn.execute(
                        "SELECT amc_code, COUNT(DISTINCT accrual_month) FROM cams_brokerage GROUP BY amc_code").fetchall():
                    file_months_map[row[0]] = file_months_map.get(row[0], 0) + row[1]
                for row in conn.execute(
                        "SELECT amc_code, COUNT(DISTINCT accrual_month) FROM kfintech_brokerage GROUP BY amc_code").fetchall():
                    file_months_map[row[0]] = file_months_map.get(row[0], 0) + row[1]

            # Inside the loop:
            months_with_file = file_months_map.get(amc, 0)

            breakdown_data.append({
                "AMC": amc,
                "RTA": df_active[df_active["amc"] == amc]["rta"].iloc[0] if amc in df_active[
                    "amc"].values else "Unknown",
                "Manual Total (Rs)": manual_val,
                "File Total (Rs)": file_val,
                "Difference (Rs)": diff,
                "Match Status": match_status,
                "Months with Manual": manual_all[manual_all["amc"] == amc].shape[0] if not manual_all.empty else 0,
                "Months with File": months_with_file,
            })
        breakdown_df = pd.DataFrame(breakdown_data)
        if breakdown_df.empty:
            st.info("No data matches the current filters.")
        else:
            if breakdown_sort == "AMC Name":
                breakdown_df = breakdown_df.sort_values("AMC")
            elif breakdown_sort == "Manual Total":
                breakdown_df = breakdown_df.sort_values("Manual Total (Rs)", ascending=False)
            elif breakdown_sort == "File Total":
                breakdown_df = breakdown_df.sort_values("File Total (Rs)", ascending=False)
            elif breakdown_sort == "Difference":
                breakdown_df = breakdown_df.sort_values("Difference (Rs)", key=abs, ascending=False)
            display_df = breakdown_df.copy()
            display_df["Manual Total (Rs)"] = display_df["Manual Total (Rs)"].apply(format_brokerage)
            display_df["File Total (Rs)"] = display_df["File Total (Rs)"].apply(format_brokerage)
            display_df["Difference (Rs)"] = display_df["Difference (Rs)"].apply(
                lambda x: format_brokerage(x) if pd.notna(x) and x != 0 else "—")
            display_df = display_df[
                ["AMC", "RTA", "Manual Total (Rs)", "File Total (Rs)", "Difference (Rs)", "Match Status"]]
            st.dataframe(display_df, use_container_width=True, hide_index=True)
            total_manual_all = breakdown_df["Manual Total (Rs)"].sum()
            total_file_all = breakdown_df["File Total (Rs)"].sum()
            total_diff_all = total_manual_all - total_file_all
            sm1, sm2, sm3 = st.columns(3)
            sm1.metric("💵 Total Manual (All AMCs)", format_brokerage(total_manual_all))
            sm2.metric("📄 Total File (All AMCs)", format_brokerage(total_file_all))
            sm3.metric("↔️ Overall Difference", format_brokerage(total_diff_all))
            export_df = breakdown_df.copy()
            export_df["Manual Total (Rs)"] = export_df["Manual Total (Rs)"].apply(lambda x: f"{x:.8f}")
            export_df["File Total (Rs)"] = export_df["File Total (Rs)"].apply(lambda x: f"{x:.8f}")
            export_df["Difference (Rs)"] = export_df["Difference (Rs)"].apply(
                lambda x: f"{x:.8f}" if pd.notna(x) else "")
            csv = export_df.to_csv(index=False).encode()
            st.download_button("⬇️ Export AMC Breakdown (CSV)", csv,
                               f"amc_breakdown_{datetime.now().strftime('%Y%m%d')}.csv", "text/csv")


# ==================== ⚙️ ADMIN PANEL ====================
elif mode == "⚙️ Admin Panel":
    st.header("⚙️ Admin Panel")
    tab_bse, tab_rta, tab_amc, tab_map, tab_db, tab_rta_map, tab_raw = st.tabs(
        ["📥 Import BSE Data", "🗂️ Import RTA Data", "🏢 AMC Config", "🔗 AMC Code Map", "🗄️ DB Info", "📦 RTA Mapping",
         "📄 Raw Data"]
    )

    with tab_bse:
        # ---- Client Master ----
        st.subheader("Client Master (BSE)")
        f1 = st.file_uploader("Client Master Excel", type=["xlsx"], key="client_file")
        replace1 = st.checkbox("Replace existing clients", key="replace_clients")
        if replace1:
            st.warning("Replace mode: ALL existing clients will be deleted and reimported.", icon="⚠️")
        else:
            st.info("Append mode: only new client codes inserted; existing ones skipped.", icon="ℹ️")
        if st.button("Import Clients") and f1:
            with st.spinner("Importing…"):
                ok, msg = data_maneger.parse_bse_client_master(f1, replace1)
                (st.success if ok else st.error)(msg)
                if ok: st.cache_data.clear()

        st.divider()

        # ---- SIP Report ----
        st.subheader("SIP Report (BSE)")
        f2 = st.file_uploader("SIP Report Excel", type=["xlsx"], key="sip_file")
        replace2 = st.checkbox("Replace existing holdings", key="replace_holdings")
        if replace2:
            st.warning("Replace mode: ALL existing holdings will be deleted and reimported.", icon="⚠️")
        else:
            st.info("Append mode: new SIPs inserted; duplicates (folio + scheme + start_date) skipped.", icon="ℹ️")
        if st.button("Import SIPs") and f2:
            with st.spinner("Importing…"):
                ok, msg, preview = data_maneger.parse_bse_sip_report(f2, replace2)
                (st.success if ok else st.error)(msg)
                if preview:
                    cols = st.columns(3)
                    if "active" in preview: cols[0].metric("Active in file", preview["active"])
                    if "cancelled" in preview: cols[1].metric("Cancelled (skipped)", preview["cancelled"])
                    if "first_order" in preview: cols[2].metric("First Order = Y", preview["first_order"])
                if ok: st.cache_data.clear()

    with tab_rta:
        st.subheader("🗂️ RTA Data Upload")
        st.caption("Upload AUM, Transaction, Folio Master, SIP, and Brokerage reports from CAMS and KFinTech.")

        # Top-level selection: RTA Provider
        provider = st.radio(
            "Select RTA Provider",
            ["🟦 CAMS", "🟩 KFinTech (Karvy)"],
            horizontal=True,
            key="rta_provider_toggle"
        )
        st.divider()

        # ==========================================
        # 🟦 CAMS SECTION
        # ==========================================
        if provider == "🟦 CAMS":
            cams_data_type = st.radio(
                "Select CAMS Data Type",
                ["📦 AUM", "💱 Transaction", "📑 Folio Master", "🔄 SIP", "💰 Brokerage"],
                horizontal=True,
                key="cams_data_type_toggle"
            )
            st.divider()

            # ---------- CAMS AUM ----------
            if cams_data_type == "📦 AUM":
                st.markdown("#### CAMS AUM Report")
                st.caption("Required columns: `FOLIOCHK`, `RUPEE_BAL`, `SCH_NAME`, `AMC_CODE`, `CLOS_BAL`.")
                aum_file = st.file_uploader("CAMS AUM CSV / TSV", type=["csv", "txt", "tsv"], key="cams_aum_file")
                replace_aum = st.checkbox("Replace existing CAMS AUM", key="replace_cams_aum",
                                          help="Checked: deletes all CAMS AUM rows, reinserts.\nUnchecked: skips rows already present (folio + scheme + rep_date).")
                if replace_aum:
                    st.warning("Replace mode: ALL existing CAMS AUM data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (folio + scheme + date) rows skipped.", icon="ℹ️")

                if st.button("📤 Upload CAMS AUM") and aum_file:
                    with st.spinner("Parsing CAMS AUM…"):
                        ok, msg, preview = data_maneger.parse_cams_aum(aum_file, replace_aum)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            am1, am2, am3, am4 = st.columns(4)
                            am1.metric("📄 Inserted", preview.get("rows", 0))
                            am2.metric("📦 Total AUM", format_aum(preview.get("total_aum", 0)))
                            am3.metric("🔁 Duplicates", preview.get("duplicates", 0))
                            am4.metric("⏭️ Skipped", preview.get("skipped", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing CAMS AUM Summary")
                with get_conn() as conn:
                    aum_summary = pd.read_sql(
                        """SELECT rep_date AS "Report Date", amc_code AS "AMC Code", COUNT(*) AS "Folios", ROUND(SUM(rupee_bal), 2) AS "Total AUM (Rs)" FROM cams_aum GROUP BY rep_date, amc_code ORDER BY rep_date DESC, 4 DESC""",
                        conn)
                    if aum_summary.empty:
                        st.info("No CAMS AUM data uploaded yet.")
                    else:
                        aum_summary["Total AUM (Rs)"] = aum_summary["Total AUM (Rs)"].apply(format_aum)
                        st.dataframe(aum_summary, use_container_width=True, hide_index=True)
                        st.metric("CAMS Grand Total", format_aum(load_total_aum()))
                        if st.button("⚠️ Clear CAMS AUM", key="clear_cams_aum"):
                            with get_conn() as conn: conn.execute("DELETE FROM cams_aum")
                            st.warning("CAMS AUM data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- CAMS TRANSACTION (WBR2) ----------
            elif cams_data_type == "💱 Transaction":
                st.markdown("#### WBR2 — Transaction Report")
                st.caption(
                    "CAMS transaction file (R2). Required columns: `FOLIO_NO`, `TRXNNO`, `AMOUNT`, `UNITS`, `PURPRICE`, `TRADDATE`.")
                r2_file = st.file_uploader("R2 CSV file", type=["csv", "txt", "tsv"], key="cams_r2_file")
                replace_r2 = st.checkbox("Replace ALL existing transaction data", key="replace_cams_r2",
                                         help="Checked: deletes all cams_transactions rows, then reinserts.\nUnchecked: inserts only new transactions (matched on trxn_no + folio).")
                if replace_r2:
                    st.warning("Replace mode: ALL existing CAMS transaction data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (trxn_no + folio) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload Transactions (R2)") and r2_file:
                    with st.spinner("Parsing transactions…"):
                        ok, msg, preview = data_maneger.parse_cams_transactions(r2_file, replace_r2)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Total Amount", format_currency(preview.get("total_amount", 0), decimals=0))
                            c3.metric("Folios", preview.get("folios", 0))
                            c4.metric("Schemes", preview.get("schemes", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing Transaction Summary")
                with get_conn() as conn:
                    txn_summary = pd.read_sql(
                        """SELECT trade_date AS "Date", amc_code AS "AMC", COUNT(*) AS "Transactions", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(amount), 2) AS "Total Amount (Rs)" FROM cams_transactions GROUP BY trade_date, amc_code ORDER BY trade_date DESC LIMIT 50""",
                        conn)
                    if txn_summary.empty:
                        st.info("No CAMS transaction data uploaded yet.")
                    else:
                        st.dataframe(txn_summary, use_container_width=True, hide_index=True)
                        if st.button("Clear All CAMS Transactions", key="clear_cams_txn"):
                            with get_conn() as conn: conn.execute("DELETE FROM cams_transactions")
                            st.warning("All CAMS transaction data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- CAMS FOLIO MASTER (WBR9) ----------
            elif cams_data_type == "📑 Folio Master":
                st.markdown("#### WBR9 — Investor Folio Master")
                st.caption(
                    "CAMS folio master file (R9). Required columns: `FOLIOCHK`, `INV_NAME`, `SCH_NAME`, `RUPEE_BAL`, `PAN_NO`.")
                r9_file = st.file_uploader("R9 CSV file", type=["csv", "txt", "tsv"], key="cams_r9_file")
                replace_r9 = st.checkbox("Replace ALL existing folio master data", key="replace_cams_r9",
                                         help="Checked: deletes all cams_folio_master rows, then reinserts.\nUnchecked: inserts only new (folio + scheme) combos.")
                if replace_r9:
                    st.warning("Replace mode: ALL existing folio master data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (folio + scheme_name) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload Folio Master (R9)") and r9_file:
                    with st.spinner("Parsing folio master…"):
                        ok, msg, preview = data_maneger.parse_cams_folio_master(r9_file, replace_r9)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Total AUM", format_aum(preview.get("total_aum", 0)))
                            c3.metric("Unique Folios", preview.get("unique_folios", 0))
                            c4.metric("Investors", preview.get("unique_investors", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing Folio Master Summary")
                with get_conn() as conn:
                    folio_summary = pd.read_sql(
                        """SELECT amc_code AS "AMC", COUNT(DISTINCT folio_no) AS "Folios", COUNT(DISTINCT pan_no) AS "Investors", COUNT(*) AS "Scheme Records", ROUND(SUM(rupee_bal), 2) AS "Total AUM (Rs)" FROM cams_folio_master GROUP BY amc_code ORDER BY 5 DESC""",
                        conn)
                    if folio_summary.empty:
                        st.info("No CAMS folio master data uploaded yet.")
                    else:
                        folio_summary["Total AUM (Rs)"] = folio_summary["Total AUM (Rs)"].apply(format_aum)
                        st.dataframe(folio_summary, use_container_width=True, hide_index=True)
                        with get_conn() as conn:
                            total_fm_aum = \
                                conn.execute("SELECT COALESCE(SUM(rupee_bal),0) FROM cams_folio_master").fetchone()[0]
                        st.metric("Grand Total AUM (Folio Master)", format_aum(total_fm_aum))
                        if st.button("Clear All Folio Master Data", key="clear_cams_fm"):
                            with get_conn() as conn: conn.execute("DELETE FROM cams_folio_master")
                            st.warning("All CAMS folio master data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- CAMS SIP MASTER (WBR49) ----------
            elif cams_data_type == "🔄 SIP":
                st.markdown("#### WBR49 — SIP Details / Master")
                st.caption(
                    "CAMS SIP master file (R49). Required columns: `FOLIO_NO`, `AUTO_TRNO`, `AUTO_AMOUNT`, `FROM_DATE`, `TO_DATE`.")
                r49_file = st.file_uploader("R49 CSV file", type=["csv", "txt", "tsv"], key="cams_r49_file")
                replace_r49 = st.checkbox("Replace ALL existing SIP master data", key="replace_cams_r49",
                                          help="Checked: deletes all cams_sip_master rows, then reinserts.\nUnchecked: inserts only new (sip_reg_no + folio) combos.")
                if replace_r49:
                    st.warning("Replace mode: ALL existing CAMS SIP master data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (sip_reg_no + folio) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload SIP Master (R49)") and r49_file:
                    with st.spinner("Parsing SIP master…"):
                        ok, msg, preview = data_maneger.parse_cams_sip_master(r49_file, replace_r49)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Active SIPs", preview.get("active", 0))
                            c3.metric("Ceased", preview.get("ceased", 0))
                            c4.metric("Completed", preview.get("completed", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing SIP Master Summary")
                with get_conn() as conn:
                    sip_summary = pd.read_sql(
                        """SELECT amc_code AS "AMC", status AS "Status", COUNT(*) AS "SIPs", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(sip_amount), 2) AS "Total SIP Amount (Rs)" FROM cams_sip_master GROUP BY amc_code, status ORDER BY amc_code, status""",
                        conn)
                    if sip_summary.empty:
                        st.info("No CAMS SIP master data uploaded yet.")
                    else:
                        st.dataframe(sip_summary, use_container_width=True, hide_index=True)
                        if st.button("Clear All SIP Master Data", key="clear_cams_sip"):
                            with get_conn() as conn: conn.execute("DELETE FROM cams_sip_master")
                            st.warning("All CAMS SIP master data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- CAMS BROKERAGE ----------
            elif cams_data_type == "💰 Brokerage":
                st.markdown("#### CAMS Brokerage File")
                st.caption(
                    "Upload tab-separated CAMS brokerage report. Required columns: `FOLIO_NO`, `BRKAGE_AMT`, `AMC_CODE`.")
                cams_file = st.file_uploader("CAMS Brokerage CSV / TSV", type=["csv", "txt", "tsv"],
                                             key="cams_brok_file")
                replace_cams = st.checkbox("Replace ALL existing CAMS brokerage data", key="replace_cams_brok",
                                           help="Checked: deletes all existing CAMS brokerage rows, then reinserts.\nUnchecked: only inserts transactions not already present (matched on trxn_no + folio + accrual_month).")
                if replace_cams:
                    st.warning("Replace mode: ALL existing CAMS brokerage data will be deleted and reimported.",
                               icon="⚠️")
                else:
                    st.info("Append mode: duplicate transactions (same trxn_no + folio + month) are silently skipped.",
                            icon="ℹ️")

                if st.button("📤 Upload CAMS Brokerage") and cams_file:
                    with st.spinner("Parsing brokerage…"):
                        ok, msg, preview = data_maneger.parse_cams_brokerage(cams_file, replace_cams)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            pm1, pm2, pm3, pm4 = st.columns(4)
                            pm1.metric("📄 Inserted", preview.get("rows", 0))
                            pm2.metric("💰 Total Brokerage", format_brokerage(preview.get("total_brokerage", 0)))
                            pm3.metric("🔁 Duplicates skipped", preview.get("duplicates", 0))
                            pm4.metric("⏭️ Invalid skipped", preview.get("skipped", 0))
                            if preview.get("months"): st.info(
                                f"Accrual months in file: **{', '.join(preview['months'])}**")
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing CAMS Brokerage Summary")
                with get_conn() as conn:
                    cams_summary = pd.read_sql(
                        """SELECT accrual_month AS "Month", COUNT(*) AS "Rows", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(brkage_amt), 2) AS "Total Brokerage (Rs)", upload_batch AS "Batch" FROM cams_brokerage GROUP BY accrual_month, upload_batch ORDER BY accrual_month DESC""",
                        conn)
                    if cams_summary.empty:
                        st.info("No CAMS brokerage data uploaded yet.")
                    else:
                        st.dataframe(cams_summary, use_container_width=True, hide_index=True)
                        if st.button("⚠️ Clear All CAMS Brokerage Data", key="clear_cams_brok"):
                            with get_conn() as conn: conn.execute("DELETE FROM cams_brokerage")
                            st.warning("All CAMS brokerage data deleted.")
                            st.cache_data.clear()
                            st.rerun()

        # ==========================================
        # 🟩 KFINTECH (KARVY) SECTION
        # ==========================================
        else:
            kfin_data_type = st.radio(
                "Select KFinTech Data Type",
                ["📦 AUM", "💱 Transaction", "📑 Folio Master", "🔄 SIP", "💰 Brokerage"],
                horizontal=True,
                key="kfin_data_type_toggle"
            )
            st.divider()

            # ---------- KFINTECH AUM ----------
            if kfin_data_type == "📦 AUM":
                st.markdown("#### KFinTech AUM Report")
                st.caption(
                    "Expected columns: `Folio Number`, `Fund Description`, `AUM`, `Balance`, `NAV`, `Report Date`.")
                kfin_file = st.file_uploader("KFinTech AUM CSV / TSV", type=["csv", "txt", "tsv"], key="kfin_aum_file")
                replace_kfin = st.checkbox("Replace existing KFinTech AUM", key="replace_kfin_aum",
                                           help="Checked: deletes all KFinTech AUM rows, reinserts.\nUnchecked: skips duplicate (folio + scheme + date) rows.")
                if replace_kfin:
                    st.warning("Replace mode: ALL existing KFinTech AUM data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (folio + scheme + date) rows skipped.", icon="ℹ️")

                if st.button("📤 Upload KFinTech AUM") and kfin_file:
                    with st.spinner("Parsing KFinTech AUM…"):
                        ok, msg, preview = data_maneger.parse_kfintech_aum(kfin_file, replace_kfin)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            km1, km2, km3, km4 = st.columns(4)
                            km1.metric("📄 Inserted", preview.get("rows", 0))
                            km2.metric("📦 Total AUM", format_aum(preview.get("total_aum", 0)))
                            km3.metric("🔁 Duplicates", preview.get("duplicates", 0))
                            km4.metric("⏭️ Skipped", preview.get("skipped", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing KFinTech AUM Summary")
                with get_conn() as conn:
                    kfin_summary = pd.read_sql(
                        """SELECT rep_date AS "Report Date", amc_code AS "AMC Code", COUNT(*) AS "Folios", ROUND(SUM(rupee_bal), 2) AS "Total AUM (Rs)" FROM kfintech_aum GROUP BY rep_date, amc_code ORDER BY rep_date DESC, 4 DESC""",
                        conn)
                    if kfin_summary.empty:
                        st.info("No KFinTech AUM data uploaded yet.")
                    else:
                        kfin_summary["Total AUM (Rs)"] = kfin_summary["Total AUM (Rs)"].apply(format_aum)
                        st.dataframe(kfin_summary, use_container_width=True, hide_index=True)
                        st.metric("KFinTech Grand Total", format_aum(load_total_kfintech_aum()))
                        if st.button("⚠️ Clear KFinTech AUM", key="clear_kfin_aum"):
                            with get_conn() as conn: conn.execute("DELETE FROM kfintech_aum")
                            st.warning("KFinTech AUM data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- KFINTECH TRANSACTION (MFSD201) ----------
            elif kfin_data_type == "💱 Transaction":
                st.markdown("#### MFSD201 — Transaction Report")
                st.caption(
                    "KFinTech transaction file (MFSD201). Required columns: `td_acno`, `td_trno`, `td_amt`, `td_units`, `td_pop`, `td_trdt`.")
                kf_r2_file = st.file_uploader("MFSD201 CSV file", type=["csv", "txt", "tsv"], key="kfin_r2_file")
                replace_kf_r2 = st.checkbox("Replace ALL existing KFinTech transaction data", key="replace_kfin_r2",
                                            help="Checked: deletes all kfintech_transactions rows, then reinserts.\nUnchecked: inserts only new transactions (matched on trxn_no + folio).")
                if replace_kf_r2:
                    st.warning("Replace mode: ALL existing KFinTech transaction data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (trxn_no + folio) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload KFinTech Transactions (MFSD201)") and kf_r2_file:
                    with st.spinner("Parsing KFinTech transactions…"):
                        ok, msg, preview = data_maneger.parse_kfintech_transactions(kf_r2_file, replace_kf_r2)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Total Amount", format_currency(preview.get("total_amount", 0), decimals=0))
                            c3.metric("Folios", preview.get("folios", 0))
                            c4.metric("Schemes", preview.get("schemes", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing KFinTech Transaction Summary")
                with get_conn() as conn:
                    txn_summary = pd.read_sql(
                        """SELECT trade_date AS "Date", fund_code AS "Fund", COUNT(*) AS "Transactions", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(amount), 2) AS "Total Amount (Rs)" FROM kfintech_transactions GROUP BY trade_date, fund_code ORDER BY trade_date DESC LIMIT 50""",
                        conn)
                    if txn_summary.empty:
                        st.info("No KFinTech transaction data uploaded yet.")
                    else:
                        st.dataframe(txn_summary, use_container_width=True, hide_index=True)
                        if st.button("Clear All KFinTech Transactions", key="clear_kfin_txn"):
                            with get_conn() as conn: conn.execute("DELETE FROM kfintech_transactions")
                            st.warning("All KFinTech transaction data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- KFINTECH FOLIO MASTER (MFSD211) ----------
            elif kfin_data_type == "📑 Folio Master":
                st.markdown("#### MFSD211 — Investor Folio Master")
                st.caption(
                    "KFinTech folio master file (MFSD211). Required columns: `Folio`, `Investor Name`, `Fund Description`, `PAN Number`.")
                kf_r9_file = st.file_uploader("MFSD211 CSV file", type=["csv", "txt", "tsv"], key="kfin_r9_file")
                replace_kf_r9 = st.checkbox("Replace ALL existing KFinTech folio master data", key="replace_kfin_r9",
                                            help="Checked: deletes all kfintech_folio_master rows, then reinserts.\nUnchecked: inserts only new (folio + scheme) combos.")
                if replace_kf_r9:
                    st.warning("Replace mode: ALL existing KFinTech folio master data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (folio + scheme_name) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload KFinTech Folio Master (MFSD211)") and kf_r9_file:
                    with st.spinner("Parsing KFinTech folio master…"):
                        ok, msg, preview = data_maneger.parse_kfintech_folio_master(kf_r9_file, replace_kf_r9)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Unique Folios", preview.get("unique_folios", 0))
                            c3.metric("Investors", preview.get("unique_investors", 0))
                            c4.metric("Skipped", preview.get("skipped", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing KFinTech Folio Master Summary")
                with get_conn() as conn:
                    folio_summary = pd.read_sql(
                        """SELECT fund_code AS "Fund", COUNT(DISTINCT folio_no) AS "Folios", COUNT(DISTINCT pan_no) AS "Investors", COUNT(*) AS "Scheme Records" FROM kfintech_folio_master GROUP BY fund_code ORDER BY 2 DESC""",
                        conn)
                    if folio_summary.empty:
                        st.info("No KFinTech folio master data uploaded yet.")
                    else:
                        st.dataframe(folio_summary, use_container_width=True, hide_index=True)
                        if st.button("Clear All KFinTech Folio Master Data", key="clear_kfin_fm"):
                            with get_conn() as conn: conn.execute("DELETE FROM kfintech_folio_master")
                            st.warning("All KFinTech folio master data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- KFINTECH SIP MASTER (MFSD243) ----------
            elif kfin_data_type == "🔄 SIP":
                st.markdown("#### MFSD243 — SIP Details / Master")
                st.caption(
                    "KFinTech SIP master file (MFSD243). Required columns: `Folio`, `RegSlno`, `Amount`, `Start Date`, `End Date`.")
                kf_r49_file = st.file_uploader("MFSD243 CSV file", type=["csv", "txt", "tsv"], key="kfin_r49_file")
                replace_kf_r49 = st.checkbox("Replace ALL existing KFinTech SIP master data", key="replace_kfin_r49",
                                             help="Checked: deletes all kfintech_sip_master rows, then reinserts.\nUnchecked: inserts only new (reg_sl_no + folio) combos.")
                if replace_kf_r49:
                    st.warning("Replace mode: ALL existing KFinTech SIP master data will be deleted.", icon="⚠️")
                else:
                    st.info("Append mode: duplicate (reg_sl_no + folio) rows are silently skipped.", icon="ℹ️")

                if st.button("Upload KFinTech SIP Master (MFSD243)") and kf_r49_file:
                    with st.spinner("Parsing KFinTech SIP master…"):
                        ok, msg, preview = data_maneger.parse_kfintech_sip_master(kf_r49_file, replace_kf_r49)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            c1, c2, c3, c4 = st.columns(4)
                            c1.metric("Inserted", preview.get("rows", 0))
                            c2.metric("Active SIPs", preview.get("active", 0))
                            c3.metric("Ceased", preview.get("ceased", 0))
                            c4.metric("Completed", preview.get("completed", 0))
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing KFinTech SIP Master Summary")
                with get_conn() as conn:
                    sip_summary = pd.read_sql(
                        """SELECT fund_code AS "Fund", status AS "Status", COUNT(*) AS "SIPs", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(sip_amount), 2) AS "Total SIP Amount (Rs)" FROM kfintech_sip_master GROUP BY fund_code, status ORDER BY fund_code, status""",
                        conn)
                    if sip_summary.empty:
                        st.info("No KFinTech SIP master data uploaded yet.")
                    else:
                        st.dataframe(sip_summary, use_container_width=True, hide_index=True)
                        if st.button("Clear All KFinTech SIP Master Data", key="clear_kfin_sip"):
                            with get_conn() as conn: conn.execute("DELETE FROM kfintech_sip_master")
                            st.warning("All KFinTech SIP master data deleted.")
                            st.cache_data.clear()
                            st.rerun()

            # ---------- KFINTECH BROKERAGE ----------
            elif kfin_data_type == "💰 Brokerage":
                st.markdown("#### KFinTech (Karvy) Brokerage File")
                st.caption(
                    "Upload tab-separated KFinTech brokerage report. Required columns: `Account Number`, `Brokerage (in Rs.)`, `Fund`.")
                kf_brok_file = st.file_uploader("KFinTech Brokerage CSV / TSV", type=["csv", "txt", "tsv"],
                                                key="kfin_brok_file")
                replace_kf_brok = st.checkbox("Replace ALL existing KFinTech brokerage data", key="replace_kfin_brok",
                                              help="Checked: deletes all existing KFinTech brokerage rows, then reinserts.\nUnchecked: only inserts transactions not already present (matched on trxn_no + folio + accrual_month).")
                if replace_kf_brok:
                    st.warning("Replace mode: ALL existing KFinTech brokerage data will be deleted and reimported.",
                               icon="⚠️")
                else:
                    st.info("Append mode: duplicate transactions (same trxn_no + folio + month) are silently skipped.",
                            icon="ℹ️")

                if st.button("📤 Upload KFinTech Brokerage") and kf_brok_file:
                    with st.spinner("Parsing KFinTech brokerage…"):
                        ok, msg, preview = data_maneger.parse_kfintech_brokerage(kf_brok_file, replace_kf_brok)
                        (st.success if ok else st.error)(msg)
                        if ok and preview:
                            pm1, pm2, pm3, pm4 = st.columns(4)
                            pm1.metric("📄 Inserted", preview.get("rows", 0))
                            pm2.metric("💰 Total Brokerage", format_brokerage(preview.get("total_brokerage", 0)))
                            pm3.metric("🔁 Duplicates skipped", preview.get("duplicates", 0))
                            pm4.metric("⏭️ Invalid skipped", preview.get("skipped", 0))
                            if preview.get("months"): st.info(
                                f"Accrual months in file: **{', '.join(preview['months'])}**")
                    st.cache_data.clear()

                st.divider()
                st.markdown("#### Existing KFinTech Brokerage Summary")
                with get_conn() as conn:
                    kf_summary = pd.read_sql(
                        """SELECT accrual_month AS "Month", COUNT(*) AS "Rows", COUNT(DISTINCT folio_no) AS "Folios", ROUND(SUM(brkage_amt), 2) AS "Total Brokerage (Rs)", upload_batch AS "Batch" FROM kfintech_brokerage GROUP BY accrual_month, upload_batch ORDER BY accrual_month DESC""",
                        conn)
                    if kf_summary.empty:
                        st.info("No KFinTech brokerage data uploaded yet.")
                    else:
                        st.dataframe(kf_summary, use_container_width=True, hide_index=True)
                        if st.button("⚠️ Clear All KFinTech Brokerage Data", key="clear_kfin_brok"):
                            with get_conn() as conn: conn.execute("DELETE FROM kfintech_brokerage")
                            st.warning("All KFinTech brokerage data deleted.")
                            st.cache_data.clear()
                            st.rerun()

    with tab_amc:
        st.subheader("Enable / Disable AMCs")
        with get_conn() as conn:
            amc_cfg = pd.read_sql("SELECT amc, rta, is_enabled FROM amc_config ORDER BY amc", conn)
        if amc_cfg.empty:
            st.info("No AMCs found. Run AMFI sync first.")
        else:
            updated_enabled = {}
            for _, row in amc_cfg.iterrows(): updated_enabled[row["amc"]] = st.checkbox(row["amc"],
                                                                                        value=bool(row["is_enabled"]),
                                                                                        key=f"amc_{row['amc']}")
            if st.button("💾 Save AMC Config"):
                with get_conn() as conn:
                    for amc, enabled in updated_enabled.items(): conn.execute(
                        "UPDATE amc_config SET is_enabled=? WHERE amc=?", (1 if enabled else 0, amc))
                st.success("AMC config saved.")
                st.cache_data.clear()
                st.rerun()

    with tab_map:
        st.subheader("🔗 AMC Code → AMC Name Mapping")
        st.caption(
            "Fetches the live AMFI NAV file, builds a scheme_code → AMC name index, "
            "then looks up every unmapped Fund Code found in your uploaded RTA files."
        )

        # ── Existing mappings table ───────────────────────────────────────────
        with get_conn() as conn:
            _existing_map_df = pd.read_sql(
                "SELECT amc_code AS 'AMC Code', amc_name AS 'AMC Name' "
                "FROM amc_code_map ORDER BY amc_code",
                conn,
            )
        if _existing_map_df.empty:
            st.info("No mappings yet — run Auto-Map or add manually below.")
        else:
            st.markdown(f"**{len(_existing_map_df)} mapped code(s)**")
            st.dataframe(_existing_map_df, use_container_width=True, hide_index=True)
            _del_code = st.text_input("Delete a mapping (enter exact AMC Code)", key="del_amc_code_input")
            if st.button("🗑️ Delete Mapping", key="del_amc_code_btn") and _del_code.strip():
                with get_conn() as conn:
                    conn.execute(
                        "DELETE FROM amc_code_map WHERE TRIM(UPPER(amc_code)) = TRIM(UPPER(?))",
                        (_del_code.strip(),),
                    )
                st.success(f"Deleted `{_del_code.strip()}`")
                st.cache_data.clear()
                st.rerun()

        st.markdown("---")

        st.markdown("#### 🪄 Smart Auto-Mapping via AMFI")
        if st.button("🪄 Auto-Map Fund Codes using AMFI Data", type="primary"):
            _log_placeholder = st.empty()
            _logs: list[str] = []


            def _log(msg: str) -> None:
                _logs.append(msg)
                _log_placeholder.code("\n".join(_logs[-60:]), language="log")
                print(f"[AUTO-MAP DEBUG] {msg}")


            with st.status("Running auto-map with Smart Fallback…", expanded=True) as _status:
                # ── Step 1: fetch AMFI NAV file ──────────────────────────────
                _log("📥 **Step 1:** Downloading AMFI NAV file…")
                try:
                    _resp = requests.get(AMFI_TEXT_URL, timeout=30)
                    _resp.raise_for_status()
                    _lines = _resp.text.splitlines()
                    _log(f"✅ {len(_lines):,} lines downloaded from AMFI")
                except Exception as _exc:
                    _log(f"❌ Download failed: {_exc}")
                    _status.update(label="❌ AMFI download failed", state="error")
                    st.stop()

                # ── Step 2: build scheme_code (int) → AMC name ───────────────
                _log("🔍 **Step 2:** Parsing scheme_code → AMC name index…")
                _scheme_amc: dict[str, str] = {}
                _cur_amc = None
                _amc_count = 0
                for _line in _lines:
                    _line = _line.strip()
                    if not _line: continue
                    if ";" not in _line:
                        if "Mutual Fund" in _line or "mutual fund" in _line.lower():
                            _cur_amc = _line.strip()
                            _amc_count += 1
                        continue
                    _parts = _line.split(";")
                    if not _parts[0].strip().isdigit() or _cur_amc is None: continue
                    _scheme_amc[_parts[0].strip()] = _cur_amc

                _log(f"✅ {len(_scheme_amc):,} scheme codes indexed from {_amc_count} AMCs")

                # ── Prepare Known AMC names for Fallback ─────────────────────
                # Combine CAMS_AMCS and KFIN_AMCS, sort by length descending to match "NIPPON INDIA" before "NIPPON"
                _all_known_amcs = sorted(list(CAMS_AMCS.union(KFIN_AMCS)), key=len, reverse=True)
                _log(f"🧠 **Smart Fallback:** Loaded {len(_all_known_amcs)} known AMC names for Scheme Name matching.")

                # ── Step 3: collect unmapped amc_code + their scheme_codes ───
                _log("🔍 **Step 3:** Scanning DB for unmapped Fund Codes…")
                from collections import defaultdict as _dd

                _code_schemes: dict[str, set] = _dd(set)

                # Tables that have scheme_code (for primary AMFI matching)
                _scan_sources = [
                    ("kfintech_aum", "amc_code", "scheme_code"),
                    ("cams_brokerage", "amc_code", "scheme_code"),
                    ("kfintech_brokerage", "amc_code", "scheme_code"),
                    ("cams_transactions", "amc_code", "scheme_code"),
                    ("kfintech_transactions", "fund_code", "scheme_code"),
                    ("cams_folio_master", "amc_code", "scheme_code"),
                    ("kfintech_folio_master", "fund_code", "scheme_code"),
                ]

                with get_conn() as conn:
                    _already_mapped = {
                        r[0].strip()
                        for r in conn.execute("SELECT amc_code FROM amc_code_map").fetchall()
                    }
                    _log(f"📊 Currently mapped codes: {len(_already_mapped)}")

                    for _tbl, _cc, _sc in _scan_sources:
                        try:
                            _cols = [row[1] for row in conn.execute(f"PRAGMA table_info({_tbl})").fetchall()]
                            if _cc not in _cols or _sc not in _cols:
                                continue

                            _rows = conn.execute(
                                f"SELECT DISTINCT {_cc}, {_sc} FROM {_tbl} "
                                f"WHERE {_cc} != '' AND {_cc} IS NOT NULL "
                                f"AND TRIM({_cc}) NOT IN (SELECT TRIM(amc_code) FROM amc_code_map)"
                            ).fetchall()

                            for _ac, _sch in _rows:
                                if _ac and str(_ac).strip() not in _already_mapped:
                                    _ac_clean = str(_ac).strip()
                                    if _sch and str(_sch).strip():
                                        _code_schemes[_ac_clean].add(str(_sch).strip())
                        except Exception as _e:
                            _log(f"⚠️ {_tbl}: Error - {_e}")

                _log(f"📊 Total unmapped codes found with scheme_codes: {len(_code_schemes)}")

                # ── Step 3b: collect scheme_names for fallback ───
                _log("🔍 **Step 3b:** Scanning DB for Scheme Names (Fallback)...")
                _code_scheme_names: dict[str, set] = _dd(set)

                # Tables that have scheme_name (for fallback matching)
                _scheme_name_tables = [
                    ("cams_aum", "amc_code", "scheme_name"),
                    ("kfintech_aum", "amc_code", "scheme_name"),
                    ("cams_folio_master", "amc_code", "scheme_name"),
                    ("kfintech_folio_master", "fund_code", "scheme_name"),
                    ("cams_transactions", "amc_code", "scheme_name"),
                    ("kfintech_transactions", "fund_code", "scheme_name"),
                ]

                with get_conn() as conn:
                    for _tbl, _cc, _sn in _scheme_name_tables:
                        try:
                            _cols = [row[1] for row in conn.execute(f"PRAGMA table_info({_tbl})").fetchall()]
                            if _cc not in _cols or _sn not in _cols:
                                continue

                            _rows = conn.execute(
                                f"SELECT DISTINCT {_cc}, {_sn} FROM {_tbl} "
                                f"WHERE {_cc} != '' AND {_cc} IS NOT NULL "
                                f"AND TRIM({_cc}) NOT IN (SELECT TRIM(amc_code) FROM amc_code_map)"
                            ).fetchall()

                            for _ac, _sname in _rows:
                                if _ac and _sname:
                                    _ac_clean = str(_ac).strip()
                                    if _ac_clean not in _already_mapped:
                                        _code_scheme_names[_ac_clean].add(str(_sname).strip())
                        except Exception as _e:
                            _log(f"⚠️ {_tbl} scheme_name scan error: {_e}")

                _log(f"📊 Found scheme names for {len(_code_scheme_names)} unmapped codes.")

                if not _code_schemes and not _code_scheme_names:
                    _log("✅ All mappable Fund Codes are already mapped!")
                    _status.update(label="✅ Nothing to map", state="complete", expanded=False)
                    _log_placeholder.empty()
                else:
                    # Combine keys from both dictionaries
                    _all_unmapped_codes = set(_code_schemes.keys()).union(set(_code_scheme_names.keys()))
                    _total = len(_all_unmapped_codes)
                    _log(f"🎯 **Step 4:** Mapping **{_total}** codes…")
                    _ok_list: list[str] = []
                    _fail_list: list[str] = []

                    with get_conn() as conn:
                        for _amc_code in _all_unmapped_codes:
                            _schemes = _code_schemes.get(_amc_code, set())
                            _snames = _code_scheme_names.get(_amc_code, set())
                            _log(f"🔎 Processing code `{_amc_code}`...")
                            _found = None

                            # 1. Try AMFI 6-digit scheme code match
                            if _schemes:
                                _log(f"   Checking {len(_schemes)} scheme code(s) against AMFI index...")
                                for _s in sorted(_schemes):
                                    if _s in _scheme_amc:
                                        _found = _scheme_amc[_s]
                                        _log(f"   ✅ AMFI MATCH: Scheme `{_s}` → AMC `{_found}`")
                                        break

                            # 2. FALLBACK: Try Scheme Name match if AMFI failed
                            if not _found and _snames:
                                _log(f"   🔄 Trying Scheme Name fallback with {len(_snames)} name(s)...")
                                # Sort by length descending to match longer names first
                                for _sname in sorted(_snames, key=len, reverse=True):
                                    _sname_upper = _sname.upper()
                                    for _known_amc in _all_known_amcs:
                                        # Check if scheme name starts with AMC name (e.g., "NIPPON INDIA SMALL CAP...")
                                        if _sname_upper.startswith(_known_amc):
                                            _found = _known_amc
                                            _log(
                                                f"   ✅ FALLBACK MATCH: Scheme Name `{_sname[:40]}...` starts with AMC `{_found}`")
                                            break
                                        # Check first word match (e.g., "JM Flexi Cap..." -> "JM FINANCIAL")
                                        elif _sname_upper.split()[0] == _known_amc.split()[0] and len(
                                                _known_amc.split()[0]) >= 2:
                                            _found = _known_amc
                                            _log(
                                                f"   ✅ FALLBACK MATCH (First Word): Scheme Name `{_sname[:40]}...` matches AMC `{_found}`")
                                            break
                                    if _found:
                                        break

                            if _found:
                                conn.execute(
                                    "INSERT INTO amc_code_map (amc_code, amc_name) VALUES (?,?) "
                                    "ON CONFLICT(amc_code) DO UPDATE SET amc_name=excluded.amc_name",
                                    (_amc_code, _found),
                                )
                                _ok_list.append(_amc_code)
                                _log(f"💾 Saved mapping: `{_amc_code}` → `{_found}`")
                            else:
                                _fail_list.append(_amc_code)
                                _log(f"❌ No match found for code `{_amc_code}`")

                    _log(f"📊 **FINAL RESULTS:**")
                    _log(f"✅ Successfully mapped: **{len(_ok_list)}** / {_total}")
                    _log(f"❌ Failed to map: **{len(_fail_list)}** / {_total}")

                    if _fail_list:
                        _log(f"💡 **TIP:** These codes could not be matched. Please map them manually below.")

                    _status.update(
                        label=f"✅ Mapped {len(_ok_list)} / {_total} codes",
                        state="complete", expanded=False,
                    )
                    _log_placeholder.empty()
                    st.cache_data.clear()
                    st.rerun()

        st.markdown("#### 🪄 Smart Auto-Mapping via Scheme Names")
        st.caption(
            "Since RTAs use internal codes (like `RMF`, `G`) that don't match AMFI's 6-digit codes, this tool reads the **Scheme Name** (e.g., *'NIPPON INDIA SMALL CAP...'*) and intelligently extracts the AMC name.")

        if st.button("🪄 Auto-Map Fund Codes via Scheme Names", type="primary"):
            _log_placeholder = st.empty()
            _logs: list[str] = []


            def _log(msg: str) -> None:
                _logs.append(msg)
                _log_placeholder.code("\n".join(_logs[-60:]), language="log")
                print(f"[AUTO-MAP DEBUG] {msg}")


            with st.status("Running Smart String Matching…", expanded=True) as _status:
                # Combine known AMCs and sort by length descending
                # (so "ADITYA BIRLA SUN LIFE" matches before "ADITYA")
                _all_known_amcs = sorted(list(CAMS_AMCS.union(KFIN_AMCS)), key=len, reverse=True)
                _log(f"🧠 Loaded {len(_all_known_amcs)} known AMC names for string matching.")

                _log("🔍 Scanning DB for unmapped Fund Codes and their Scheme Names...")
                from collections import defaultdict as _dd

                _code_scheme_names: dict[str, set] = _dd(set)

                # Tables that contain the descriptive scheme names
                _scheme_name_tables = [
                    ("cams_aum", "amc_code", "scheme_name"),
                    ("kfintech_aum", "amc_code", "scheme_name"),
                    ("cams_folio_master", "amc_code", "scheme_name"),
                    ("kfintech_folio_master", "fund_code", "scheme_name"),
                    ("cams_transactions", "amc_code", "scheme_name"),
                    ("kfintech_transactions", "fund_code", "scheme_name"),
                ]

                with get_conn() as conn:
                    _already_mapped = {
                        r[0].strip()
                        for r in conn.execute("SELECT amc_code FROM amc_code_map").fetchall()
                    }
                    _log(f"📊 Currently mapped codes: {len(_already_mapped)}")

                    for _tbl, _cc, _sn in _scheme_name_tables:
                        try:
                            _cols = [row[1] for row in conn.execute(f"PRAGMA table_info({_tbl})").fetchall()]
                            if _cc not in _cols or _sn not in _cols:
                                continue

                            _rows = conn.execute(
                                f"SELECT DISTINCT {_cc}, {_sn} FROM {_tbl} "
                                f"WHERE {_cc} != '' AND {_cc} IS NOT NULL "
                                f"AND TRIM({_cc}) NOT IN (SELECT TRIM(amc_code) FROM amc_code_map)"
                            ).fetchall()

                            for _ac, _sname in _rows:
                                if _ac and _sname:
                                    _ac_clean = str(_ac).strip()
                                    if _ac_clean not in _already_mapped:
                                        _code_scheme_names[_ac_clean].add(str(_sname).strip())
                        except Exception as _e:
                            _log(f"⚠️ {_tbl} scan error: {_e}")

                _log(f"📊 Found scheme names for {len(_code_scheme_names)} unmapped codes.")

                if not _code_scheme_names:
                    _log("✅ All mappable Fund Codes are already mapped!")
                    _status.update(label="✅ Nothing to map", state="complete", expanded=False)
                    _log_placeholder.empty()
                else:
                    _total = len(_code_scheme_names)
                    _log(f"🎯 **Step 2:** Mapping **{_total}** codes via Scheme Name matching…")
                    _ok_list: list[str] = []
                    _fail_list: list[str] = []

                    with get_conn() as conn:
                        for _amc_code, _snames in _code_scheme_names.items():
                            _log(f"🔎 Processing code `{_amc_code}` ({len(_snames)} scheme names)...")
                            _found = None

                            # Try to match any scheme name against known AMCs
                            for _sname in sorted(_snames, key=len, reverse=True):
                                _sname_upper = _sname.upper()
                                for _known_amc in _all_known_amcs:
                                    _known_upper = _known_amc.upper()

                                    # 1. Exact Prefix Match (e.g., "NIPPON INDIA SMALL CAP..." starts with "NIPPON INDIA")
                                    if _sname_upper.startswith(_known_upper):
                                        _found = _known_amc
                                        _log(f"   ✅ PREFIX MATCH: `{_sname[:40]}...` starts with `{_found}`")
                                        break

                                    # 2. Substring Match (e.g., "Small Cap Fund - Nippon India" contains "NIPPON INDIA")
                                    elif _known_upper in _sname_upper:
                                        _found = _known_amc
                                        _log(f"   ✅ SUBSTRING MATCH: `{_sname[:40]}...` contains `{_found}`")
                                        break

                                    # 3. First Word Match (e.g., "JM Flexi Cap" -> "JM FINANCIAL")
                                    elif _sname_upper.split()[0] == _known_upper.split()[0] and len(
                                            _known_upper.split()[0]) >= 3:
                                        _found = _known_amc
                                        _log(f"   ✅ FIRST WORD MATCH: `{_sname[:40]}...` matches `{_found}`")
                                        break

                                if _found:
                                    break

                            if _found:
                                conn.execute(
                                    "INSERT INTO amc_code_map (amc_code, amc_name) VALUES (?,?) "
                                    "ON CONFLICT(amc_code) DO UPDATE SET amc_name=excluded.amc_name",
                                    (_amc_code, _found),
                                )
                                _ok_list.append(_amc_code)
                                _log(f"💾 Saved mapping: `{_amc_code}` → `{_found}`")
                            else:
                                _fail_list.append(_amc_code)
                                _log(f"❌ No match found for code `{_amc_code}`")

                    _log(f"📊 **FINAL RESULTS:**")
                    _log(f"✅ Successfully mapped: **{len(_ok_list)}** / {_total}")
                    _log(f"❌ Failed to map: **{len(_fail_list)}** / {_total}")

                    if _fail_list:
                        _log(f"💡 **TIP:** These codes could not be matched. Please map them manually below.")

                    _status.update(
                        label=f"✅ Mapped {len(_ok_list)} / {_total} codes",
                        state="complete", expanded=False,
                    )
                    _log_placeholder.empty()
                    st.cache_data.clear()
                    st.rerun()

        # ── Manual mapping ────────────────────────────────────────────────────
        st.markdown("#### 📋 Manual Mapping")
        cams_codes = load_distinct_all_amc_codes()
        current_map = load_amc_code_map()
        with get_conn() as conn:
            known_amcs = sorted({r[0] for r in conn.execute(
                "SELECT DISTINCT amc FROM holdings WHERE amc IS NOT NULL AND amc != ''").fetchall()})

        if not cams_codes:
            st.info("No RTA data uploaded yet.")
        elif not known_amcs:
            st.info("No holdings imported yet.")
        else:
            _unmapped = [c for c in cams_codes if c not in current_map]
            _mapped = [c for c in cams_codes if c in current_map]
            col_m, col_u = st.columns(2)
            col_m.metric("✅ Already Mapped", len(_mapped))
            col_u.metric("⚠️ Unmapped", len(_unmapped))
            if _unmapped:
                st.warning(
                    f"{len(_unmapped)} code(s) still need mapping: "
                    f"{', '.join(_unmapped[:10])}{'...' if len(_unmapped) > 10 else ''}"
                )
            st.divider()
            updated_map: dict[str, str] = {}
            cols_per_row = 2
            rows_needed = -(-len(cams_codes) // cols_per_row)
            for row_i in range(rows_needed):
                cols = st.columns(cols_per_row)
                for col_i in range(cols_per_row):
                    idx = row_i * cols_per_row + col_i
                    if idx >= len(cams_codes):
                        break
                    code = cams_codes[idx]
                    existing = current_map.get(code, "")
                    options = [""] + known_amcs
                    default_idx = options.index(existing) if existing in options else 0
                    with cols[col_i]:
                        label = f"✅ **{code}** → *{existing}*" if existing else f"⚠️ **{code}** *(unmapped)*"
                        sel = st.selectbox(label, options, index=default_idx, key=f"amc_map_{code}",
                                           placeholder="Select AMC name…")
                        updated_map[code] = sel
            if st.button("💾 Save Mappings", type="primary"):
                with get_conn() as conn:
                    for code, name in updated_map.items():
                        if name:
                            conn.execute(
                                "INSERT INTO amc_code_map (amc_code, amc_name) VALUES (?,?) "
                                "ON CONFLICT(amc_code) DO UPDATE SET amc_name=excluded.amc_name",
                                (code.strip(), name),
                            )
                        else:
                            conn.execute("DELETE FROM amc_code_map WHERE amc_code=?", (code.strip(),))
                st.success("Mappings saved.")
                st.cache_data.clear()
                st.rerun()

    with tab_db:
        st.subheader("Database Stats")
        with get_conn() as conn:
            stats = {
                "Clients": conn.execute("SELECT COUNT(*) FROM clients").fetchone()[0],
                "Holdings": conn.execute("SELECT COUNT(*) FROM holdings").fetchone()[0],
                "Schemes": conn.execute("SELECT COUNT(*) FROM amc_schemes").fetchone()[0],
                "Brokerage": conn.execute("SELECT COUNT(*) FROM monthly_brokerage").fetchone()[0],
                "CAMS Transactions": conn.execute("SELECT COUNT(*) FROM cams_transactions").fetchone()[0],
                "CAMS Folio Master": conn.execute("SELECT COUNT(*) FROM cams_folio_master").fetchone()[0],
                "CAMS SIP Master": conn.execute("SELECT COUNT(*) FROM cams_sip_master").fetchone()[0],
                "CAMS AUM rows": conn.execute("SELECT COUNT(*) FROM cams_aum").fetchone()[0],
                "CAMS Brokerage rows": conn.execute("SELECT COUNT(*) FROM cams_brokerage").fetchone()[0],
                "KFinTech Transactions": conn.execute("SELECT COUNT(*) FROM kfintech_transactions").fetchone()[0],
                "KFinTech Folio Master": conn.execute("SELECT COUNT(*) FROM kfintech_folio_master").fetchone()[0],
                "KFinTech SIP Master": conn.execute("SELECT COUNT(*) FROM kfintech_sip_master").fetchone()[0],
                "KFinTech AUM rows": conn.execute("SELECT COUNT(*) FROM kfintech_aum").fetchone()[0],
                "KFinTech Brokerage rows": conn.execute("SELECT COUNT(*) FROM kfintech_brokerage").fetchone()[0],
            }
        for k, v in stats.items(): st.metric(k, v)
        if st.button("⚠️ Clear All Holdings"):
            with get_conn() as conn: conn.execute("DELETE FROM holdings")
            st.warning("All holdings deleted.")
            st.cache_data.clear()
            st.rerun()

    with tab_rta_map:
        st.subheader("📦 RTA Mapping")
        st.info(
            "RTA is assigned **automatically** when you upload files:\n"
            "- Files uploaded under **CAMS** sections → RTA = `CAMS`\n"
            "- Files uploaded under **KFinTech** sections → RTA = `KFinTech`\n \n"
            "The table below shows the current auto-detected RTA for every AMC in your holdings. "
            "If anything looks wrong, use the manual overrides below.",
            icon="ℹ️"
        )

        with get_conn() as conn:
            amc_rta_df = pd.read_sql(
                "SELECT h.amc, COALESCE(ac.rta, 'Unknown') as rta "
                "FROM (SELECT DISTINCT amc FROM holdings WHERE amc != '') h "
                "LEFT JOIN amc_config ac ON h.amc = ac.amc "
                "ORDER BY h.amc",
                conn
            )

        if amc_rta_df.empty:
            st.info("No AMCs in holdings yet.")
        else:
            st.dataframe(
                amc_rta_df.rename(columns={"amc": "AMC", "rta": "Current RTA"}),
                use_container_width=True, hide_index=True
            )
            st.divider()
            st.markdown("#### Manual Override (if auto-detection is wrong)")
            updated_rtas = {}
            rta_options = ["CAMS", "KFinTech", "Unknown"]
            for _, row in amc_rta_df.iterrows():
                cur = row["rta"] if row["rta"] in rta_options else "Unknown"
                updated_rtas[row["amc"]] = st.selectbox(
                    row["amc"], rta_options,
                    index=rta_options.index(cur),
                    key=f"rta_{row['amc']}"
                )
            if st.button("💾 Save RTA Overrides", type="primary"):
                with get_conn() as conn:
                    for amc, rta in updated_rtas.items():
                        conn.execute(
                            "INSERT INTO amc_config (amc, rta) VALUES (?,?) "
                            "ON CONFLICT(amc) DO UPDATE SET rta=excluded.rta",
                            (amc, rta)
                        )
                    conn.execute(
                        "UPDATE holdings SET rta = "
                        "(SELECT rta FROM amc_config WHERE amc = holdings.amc) "
                        "WHERE amc IN (SELECT amc FROM amc_config)"
                    )
                st.success("RTA overrides saved & synced to holdings.")
                st.cache_data.clear()
                st.rerun()

    with tab_raw:
        st.subheader("📄 Raw Data Explorer")
        st.caption("View raw uploaded data directly from the database with original column names.")

        # Added "All" to the RTA options
        rta_sel = st.radio("Select RTA", ["All", "CAMS", "KFinTech"], horizontal=True, key="raw_rta")
        type_sel = st.radio("Select Data Type", ["Transaction", "Folio Master", "AUM", "SIP", "Brokerage"],
                            horizontal=True, key="raw_type")

        # Map data types to their respective CAMS and KFinTech tables
        type_to_tables = {
            "Transaction": ("cams_transactions", "kfintech_transactions"),
            "Folio Master": ("cams_folio_master", "kfintech_folio_master"),
            "AUM": ("cams_aum", "kfintech_aum"),
            "SIP": ("cams_sip_master", "kfintech_sip_master"),
            "Brokerage": ("cams_brokerage", "kfintech_brokerage"),
        }

        cams_table, kfin_table = type_to_tables.get(type_sel, (None, None))

        if cams_table and kfin_table:
            with get_conn() as conn:
                if rta_sel == "All":
                    # Fetch from both tables and add a Source identifier
                    df_cams = pd.read_sql(f"SELECT *, 'CAMS' as Source_RTA FROM {cams_table} LIMIT 1000", conn)
                    df_kfin = pd.read_sql(f"SELECT *, 'KFinTech' as Source_RTA FROM {kfin_table} LIMIT 1000", conn)

                    # Combine them (pandas automatically aligns columns and fills missing ones with NaN)
                    df_raw = pd.concat([df_cams, df_kfin], ignore_index=True)

                    total_cams = conn.execute(f"SELECT COUNT(*) FROM {cams_table}").fetchone()[0]
                    total_kfin = conn.execute(f"SELECT COUNT(*) FROM {kfin_table}").fetchone()[0]
                    total_rows = total_cams + total_kfin

                    # Move 'Source_RTA' to the very first column for better visibility
                    if 'Source_RTA' in df_raw.columns:
                        cols = ['Source_RTA'] + [c for c in df_raw.columns if c != 'Source_RTA']
                        df_raw = df_raw[cols]

                elif rta_sel == "CAMS":
                    df_raw = pd.read_sql(f"SELECT * FROM {cams_table} LIMIT 1000", conn)
                    total_rows = conn.execute(f"SELECT COUNT(*) FROM {cams_table}").fetchone()[0]
                else:  # KFinTech
                    df_raw = pd.read_sql(f"SELECT * FROM {kfin_table} LIMIT 1000", conn)
                    total_rows = conn.execute(f"SELECT COUNT(*) FROM {kfin_table}").fetchone()[0]

            # Dynamic metric label
            if rta_sel == "All":
                metric_label = f"Total Records ({cams_table} & {kfin_table})"
                limit_text = f"{total_rows:,} (Showing up to 1,000 per RTA)"
            else:
                target_table = cams_table if rta_sel == "CAMS" else kfin_table
                metric_label = f"Total Records in {target_table}"
                limit_text = f"{total_rows:,} (Showing up to 1,000)"

            st.metric(metric_label, limit_text)

            if not df_raw.empty:
                st.dataframe(df_raw, use_container_width=True, hide_index=True)

                # Download button
                csv = df_raw.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="⬇️ Download Raw Data (CSV)",
                    data=csv,
                    file_name=f"{rta_sel}_{type_sel.replace(' ', '_')}_raw.csv",
                    mime="text/csv",
                )
            else:
                st.info(f"No data found for {type_sel} ({rta_sel}). Please upload data in the 'Import RTA Data' tab.")
